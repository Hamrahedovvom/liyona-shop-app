import 'dart:async';
import 'package:flutter/material.dart';
import '../core/theme.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget { const SplashScreen({super.key}); @override State<SplashScreen> createState()=>_SplashScreenState(); }
class _SplashScreenState extends State<SplashScreen> {
  @override void initState(){ super.initState(); Timer(const Duration(seconds:2),()=>Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const HomeScreen()))); }
  @override Widget build(BuildContext context)=>Scaffold(body:Container(
    decoration:const BoxDecoration(gradient:LinearGradient(colors:[Colors.white,Color(0xFFFFF2F8),Colors.white],begin:Alignment.topLeft,end:Alignment.bottomRight)),
    child:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
      const Icon(Icons.checkroom_rounded,size:110,color:LiyonaTheme.pink),
      const SizedBox(height:12),
      const Text('Liyona',style:TextStyle(fontSize:54,fontWeight:FontWeight.w600,color:LiyonaTheme.blue,fontFamily:'serif')),
      const SizedBox(height:16),
      Text('زیبایی در سبک زندگی تو',style:Theme.of(context).textTheme.titleMedium),
    ])),
  ));
}
