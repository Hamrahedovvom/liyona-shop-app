import 'package:flutter/material.dart';
import '../services/api.dart';
import '../models/product.dart';
import '../widgets/product_card.dart';
import '../core/theme.dart';
import 'login_screen.dart';
import 'orders_screen.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen>{ late Future<List<Product>> future;
 @override void initState(){super.initState();future=api.products();}
 @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(
  appBar:AppBar(title:const Row(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.checkroom,color:LiyonaTheme.pink),SizedBox(width:8),Text('Liyona',style:TextStyle(color:LiyonaTheme.blue,fontFamily:'serif',fontSize:28))]),centerTitle:true,actions:[IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const LoginScreen())),icon:const Icon(Icons.person_outline))]),
  body:RefreshIndicator(onRefresh:()async{setState(()=>future=api.products());await future;},child:ListView(padding:const EdgeInsets.all(16),children:[
    TextField(onSubmitted:(v)=>setState(()=>future=api.products(search:v)),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'جستجوی محصولات، برندها و ...')),
    const SizedBox(height:14),Container(height:190,decoration:BoxDecoration(borderRadius:BorderRadius.circular(22),gradient:const LinearGradient(colors:[Color(0xFFFFDCEB),Color(0xFFE7F0FF)])),child:Padding(padding:const EdgeInsets.all(22),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[const Text('داستان استایل جدید تو',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold,color:LiyonaTheme.pink)),const SizedBox(height:8),const Text('جدیدترین محصولات لیونا را ببین'),const SizedBox(height:14),FilledButton(onPressed:(){},child:const Text('مشاهده محصولات'))]))),
    const SizedBox(height:22),const Text('پیشنهاد ویژه',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold)),const SizedBox(height:10),
    FutureBuilder<List<Product>>(future:future,builder:(context,s){if(s.connectionState!=ConnectionState.done)return const Center(child:Padding(padding:EdgeInsets.all(40),child:CircularProgressIndicator())); if(s.hasError)return const Center(child:Text('دریافت محصولات ناموفق بود')); final items=s.data??[]; return GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,childAspectRatio:.68,crossAxisSpacing:10,mainAxisSpacing:10),itemCount:items.length,itemBuilder:(_,i)=>ProductCard(p:items[i]));}),
  ])),
  bottomNavigationBar:NavigationBar(selectedIndex:0,destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'خانه'),NavigationDestination(icon:Icon(Icons.grid_view),label:'دسته‌بندی'),NavigationDestination(icon:Icon(Icons.shopping_cart_outlined),label:'سبد خرید'),NavigationDestination(icon:Icon(Icons.inventory_2_outlined),label:'سفارش‌ها'),NavigationDestination(icon:Icon(Icons.person_outline),label:'حساب من')],onDestinationSelected:(i){if(i==3)Navigator.push(context,MaterialPageRoute(builder:(_)=>const OrdersScreen()));if(i==4)Navigator.push(context,MaterialPageRoute(builder:(_)=>const LoginScreen()));}),
 )));
}
