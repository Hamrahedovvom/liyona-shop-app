import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/product.dart';
import '../core/theme.dart';

class ProductCard extends StatelessWidget {
  final Product p; const ProductCard({super.key,required this.p});
  @override Widget build(BuildContext context)=>Card(elevation:0,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18),side:const BorderSide(color:Color(0xFFF0F0F0))),child:Padding(padding:const EdgeInsets.all(8),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Expanded(child:ClipRRect(borderRadius:BorderRadius.circular(14),child:Container(color:const Color(0xFFFAFAFA),width:double.infinity,child:p.image.isEmpty?const Icon(Icons.image_outlined):CachedNetworkImage(imageUrl:p.image,fit:BoxFit.cover,errorWidget:(_,__,___)=>const Icon(Icons.broken_image_outlined))))),
    const SizedBox(height:8),Text(p.name,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w600)),
    const SizedBox(height:4),Text(p.sale.isNotEmpty?p.sale:p.regular,textDirection:TextDirection.ltr,style:const TextStyle(color:LiyonaTheme.pink,fontWeight:FontWeight.bold)),
  ])));
}
