import 'package:flutter/material.dart';

class LiyonaTheme {
  static const pink = Color(0xFFE50064);
  static const blue = Color(0xFF1565C0);
  static ThemeData get light => ThemeData(
    useMaterial3: true,
    fontFamily: 'sans',
    scaffoldBackgroundColor: Colors.white,
    colorScheme: ColorScheme.fromSeed(seedColor: pink, primary: pink, secondary: blue),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFFF7F7FB),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
    ),
  );
}
