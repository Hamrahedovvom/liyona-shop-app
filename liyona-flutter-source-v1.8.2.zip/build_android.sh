#!/usr/bin/env bash
set -euo pipefail

# Recreate a clean Android host project compatible with the Flutter SDK used by CI.
rm -rf android
flutter create --platforms=android --org com.liyona .

# Remove only Flutter's generated template test; it imports the generated package name
# and is not part of the Liyona application.
rm -f test/widget_test.dart

MANIFEST="android/app/src/main/AndroidManifest.xml"
python3 - <<'PY'
from pathlib import Path
p = Path("android/app/src/main/AndroidManifest.xml")
s = p.read_text()
perms = [
    '<uses-permission android:name="android.permission.INTERNET"/>',
    '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>',
]
insert = "\n    ".join(x for x in perms if x not in s)
if insert:
    s = s.replace("<manifest", "<manifest", 1)
    pos = s.find(">")
    s = s[:pos+1] + "\n    " + insert + s[pos+1:]
    p.write_text(s)
PY

flutter pub get
dart run flutter_launcher_icons
dart run flutter_native_splash:create
flutter analyze --no-fatal-infos --no-fatal-warnings
flutter build apk --release
printf '\nAPK: build/app/outputs/flutter-apk/app-release.apk\n'
