import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/product.dart';
import '../core/theme.dart';
import '../utils/format.dart';
import '../screens/product_detail_screen.dart';

class ProductCard extends StatelessWidget {
  final Product p;
  const ProductCard({super.key, required this.p});

  @override
  Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(20),
    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailScreen(product: p))),
    child: Card(
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: Color(0xFFF2E9ED))),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: Stack(children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  color: const Color(0xFFF8F8F8),
                  width: double.infinity,
                  height: double.infinity,
                  child: p.image.isEmpty
                      ? const Icon(Icons.image_outlined)
                      : CachedNetworkImage(imageUrl: p.image, fit: BoxFit.cover, errorWidget: (_, __, ___) => const Icon(Icons.broken_image_outlined)),
                ),
              ),
              Positioned(top: 8, left: 8, child: Container(padding: const EdgeInsets.all(7), decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle), child: const Icon(Icons.favorite_border, size: 18))),
            ]),
          ),
          const SizedBox(height: 9),
          Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, height: 1.45)),
          const SizedBox(height: 5),
          if (p.sale.isNotEmpty) ...[
            Text(money(p.regular), textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 11, color: Colors.grey, decoration: TextDecoration.lineThrough)),
            Text(money(p.sale), textDirection: TextDirection.ltr, style: const TextStyle(color: LiyonaTheme.pink, fontWeight: FontWeight.w800)),
          ] else
            Text(money(p.priceHtml.isNotEmpty ? p.priceHtml : p.regular), textDirection: TextDirection.ltr, style: const TextStyle(color: LiyonaTheme.pink, fontWeight: FontWeight.w800)),
        ]),
      ),
    ),
  );
}
