class Product {
  final int id;
  final String name;
  final String image;
  final String priceHtml;
  final String regular;
  final String sale;

  Product({
    required this.id,
    required this.name,
    required this.image,
    required this.priceHtml,
    required this.regular,
    required this.sale,
  });

  factory Product.fromJson(Map<String, dynamic> j) {
    final regular = (j['regular_price'] ?? '').toString();
    final sale = (j['sale_price'] ?? '').toString();
    final price = (j['price'] ?? '').toString();

    return Product(
      id: j['id'] ?? 0,
      name: j['name'] ?? '',
      image: (j['image'] ?? '').toString(),
      priceHtml: price,
      regular: regular,
      sale: sale,
    );
  }
}
