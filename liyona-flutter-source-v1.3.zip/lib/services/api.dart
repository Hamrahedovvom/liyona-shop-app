import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../core/config.dart';
import '../models/product.dart';

class ApiService {
  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(seconds: 25),
    headers: {'Accept': 'application/json'},
  ));

  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  String? cartToken;

  Future<Map<String, dynamic>> config() async {
    final r = await _dio.get('${AppConfig.customApi}/config');
    return Map<String, dynamic>.from(r.data);
  }

  Future<List<Product>> products({int page = 1, String? search}) async {
    final r = await _dio.get('${AppConfig.customApi}/products', queryParameters: {
      'page': page,
      'per_page': 20,
      if (search != null && search.isNotEmpty) 'search': search,
    });
    final data = Map<String, dynamic>.from(r.data);
    return List<dynamic>.from(data['items'] ?? [])
        .map((e) => Product.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<Map<String, dynamic>> product(int id) async {
    final r = await _dio.get('${AppConfig.customApi}/product/$id');
    final data = Map<String, dynamic>.from(r.data);
    return Map<String, dynamic>.from(data['product'] ?? {});
  }

  Future<List<dynamic>> categories() async {
    final r = await _dio.get('${AppConfig.customApi}/categories');
    final data = Map<String, dynamic>.from(r.data);
    return List<dynamic>.from(data['items'] ?? []);
  }

  Future<void> requestOtp(String phone) async {
    await _dio.post('${AppConfig.customApi}/request-otp', data: {'phone': phone});
  }

  Future<void> verifyOtp(String phone, String code) async {
    final r = await _dio.post('${AppConfig.customApi}/verify-otp', data: {'phone': phone, 'code': code});
    await _storage.write(key: 'auth_token', value: r.data['token']);
  }

  Future<bool> isLoggedIn() async => (await _storage.read(key: 'auth_token'))?.isNotEmpty == true;

  Future<void> logout() => _storage.delete(key: 'auth_token');

  Future<Options> _authOptions() async {
    final t = await _storage.read(key: 'auth_token');
    return Options(headers: t == null ? {} : {'Authorization': 'Bearer $t'});
  }

  Future<Map<String, dynamic>> me() async {
    final r = await _dio.get('${AppConfig.customApi}/me', options: await _authOptions());
    return Map<String, dynamic>.from(r.data['user'] ?? {});
  }

  Future<List<dynamic>> myOrders() async {
    final r = await _dio.get('${AppConfig.customApi}/me/orders', options: await _authOptions());
    final data = Map<String, dynamic>.from(r.data);
    return List<dynamic>.from(data['items'] ?? []);
  }

  Future<Map<String, dynamic>> trackOrder(String id, String phone) async {
    final r = await _dio.post('${AppConfig.customApi}/track-order', data: {'order_id': id, 'phone': phone});
    return Map<String, dynamic>.from(r.data);
  }

  Options _cartOptions() => Options(headers: {if (cartToken != null) 'Cart-Token': cartToken});

  void _captureCartToken(Response r) {
    final v = r.headers.value('Cart-Token');
    if (v != null && v.isNotEmpty) cartToken = v;
  }

  Future<Map<String, dynamic>> cart() async {
    final r = await _dio.get('${AppConfig.storeApi}/cart', options: _cartOptions());
    _captureCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }

  Future<Map<String, dynamic>> addToCart(int productId, {int quantity = 1}) async {
    if (cartToken == null) await cart();
    final r = await _dio.post(
      '${AppConfig.storeApi}/cart/add-item',
      data: {'id': productId, 'quantity': quantity},
      options: _cartOptions(),
    );
    _captureCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }

  Future<Map<String, dynamic>> removeCartItem(String key) async {
    final r = await _dio.post('${AppConfig.storeApi}/cart/remove-item', data: {'key': key}, options: _cartOptions());
    _captureCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }
}

final api = ApiService();
