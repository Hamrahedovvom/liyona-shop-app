import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../services/api.dart';
import '../models/product.dart';
import '../widgets/product_card.dart';
import '../core/theme.dart';

class HomeScreen extends StatefulWidget {
  final ValueChanged<int> onSelectTab;
  const HomeScreen({super.key, required this.onSelectTab});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<Product>> products;
  late Future<List<dynamic>> categories;
  final search = TextEditingController();

  @override
  void initState() {
    super.initState();
    products = api.products();
    categories = api.categories();
  }

  void refreshProducts([String? q]) => setState(() => products = api.products(search: q));

  @override
  Widget build(BuildContext context) => SafeArea(
    child: RefreshIndicator(
      onRefresh: () async {
        setState(() { products = api.products(); categories = api.categories(); });
        await products;
      },
      child: CustomScrollView(slivers: [
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
          child: Column(children: [
            Row(children: [
              IconButton(onPressed: () => widget.onSelectTab(4), icon: const Icon(Icons.person_outline)),
              const Spacer(),
              Image.asset('assets/images/liyona_logo.jpg', height: 52),
              const Spacer(),
              IconButton(onPressed: () => widget.onSelectTab(2), icon: const Icon(Icons.shopping_bag_outlined)),
            ]),
            const SizedBox(height: 10),
            TextField(controller: search, onSubmitted: refreshProducts, decoration: InputDecoration(prefixIcon: const Icon(Icons.search), suffixIcon: IconButton(onPressed: () { search.clear(); refreshProducts(); }, icon: const Icon(Icons.close)), hintText: 'جستجو بین محصولات لیونا...')),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(26),
                gradient: const LinearGradient(colors: [Color(0xFFFFDCEB), Color(0xFFF4E7FF), Color(0xFFE7F2FF)], begin: Alignment.topRight, end: Alignment.bottomLeft),
              ),
              child: Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('استایل جدیدت از اینجا شروع میشه', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: LiyonaTheme.pink, height: 1.5)),
                  const SizedBox(height: 6),
                  const Text('جدیدترین انتخاب‌ها، تخفیف‌ها و ترندها'),
                  const SizedBox(height: 14),
                  FilledButton(onPressed: () => widget.onSelectTab(1), child: const Text('مشاهده دسته‌بندی‌ها')),
                ])),
                const SizedBox(width: 12),
                Container(width: 82, height: 118, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .65), borderRadius: BorderRadius.circular(20)), child: const Icon(Icons.auto_awesome, size: 48, color: LiyonaTheme.pink)),
              ]),
            ),
            const SizedBox(height: 16),
            Row(children: const [
              Expanded(child: _Feature(icon: Icons.verified_outlined, text: 'ضمانت اصالت')),
              SizedBox(width: 8),
              Expanded(child: _Feature(icon: Icons.local_shipping_outlined, text: 'ارسال سریع')),
              SizedBox(width: 8),
              Expanded(child: _Feature(icon: Icons.lock_outline, text: 'خرید امن')),
            ]),
          ]),
        )),
        SliverToBoxAdapter(child: FutureBuilder<List<dynamic>>(
          future: categories,
          builder: (context, s) {
            final items = s.data ?? [];
            if (items.isEmpty) return const SizedBox(height: 16);
            return Padding(
              padding: const EdgeInsets.only(top: 22),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Row(children: [Text('دسته‌بندی‌ها', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)), const Spacer(), TextButton(onPressed: () => widget.onSelectTab(1), child: const Text('مشاهده همه'))])),
                SizedBox(height: 112, child: ListView.separated(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), itemCount: items.length.clamp(0, 10), separatorBuilder: (_, __) => const SizedBox(width: 12), itemBuilder: (_, i) {
                  final c = items[i] as Map<String, dynamic>;
                  final image = (c['image'] ?? '').toString();
                  return SizedBox(width: 82, child: Column(children: [
                    CircleAvatar(radius: 34, backgroundColor: const Color(0xFFFFEDF4), backgroundImage: image.isNotEmpty ? CachedNetworkImageProvider(image) : null, child: image.isEmpty ? const Icon(Icons.category_outlined) : null),
                    const SizedBox(height: 7),
                    Text(c['name']?.toString() ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                  ]));
                })),
              ]),
            );
          },
        )),
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 10), child: Row(children: [Text('پیشنهادهای لیونا', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)), const Spacer(), const Icon(Icons.local_fire_department, color: LiyonaTheme.pink)]))),
        FutureBuilder<List<Product>>(
          future: products,
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) return const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(50), child: Center(child: CircularProgressIndicator())));
            if (s.hasError) return const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(30), child: Center(child: Text('دریافت محصولات ناموفق بود'))));
            final items = s.data ?? [];
            return SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .63, crossAxisSpacing: 12, mainAxisSpacing: 12),
                delegate: SliverChildBuilderDelegate((_, i) => ProductCard(p: items[i]), childCount: items.length),
              ),
            );
          },
        ),
      ]),
    ),
  );
}

class _Feature extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Feature({required this.icon, required this.text});
  @override Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 8),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFF1E8EC))),
    child: Column(children: [Icon(icon, color: LiyonaTheme.pink, size: 22), const SizedBox(height: 5), Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700))]),
  );
}
