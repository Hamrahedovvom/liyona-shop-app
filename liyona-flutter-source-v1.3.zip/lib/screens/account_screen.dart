import 'package:flutter/material.dart';
import '../services/api.dart';
import 'login_screen.dart';

class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});
  @override State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  Future<bool> status = api.isLoggedIn();

  Future<void> login() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    setState(() => status = api.isLoggedIn());
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: FutureBuilder<bool>(
      future: status,
      builder: (context, s) {
        final logged = s.data == true;
        return ListView(padding: const EdgeInsets.all(18), children: [
          const SizedBox(height: 10),
          Center(child: CircleAvatar(radius: 46, backgroundColor: const Color(0xFFFFE4EE), child: Icon(logged ? Icons.person : Icons.person_outline, size: 48))),
          const SizedBox(height: 14),
          Center(child: Text(logged ? 'حساب کاربری لیونا' : 'به حساب لیونا وارد شو', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900))),
          const SizedBox(height: 22),
          if (!logged) SizedBox(height: 52, child: FilledButton.icon(onPressed: login, icon: const Icon(Icons.login), label: const Text('ورود / عضویت با موبایل'))),
          if (logged) ...[
            ListTile(leading: const Icon(Icons.receipt_long_outlined), title: const Text('سفارش‌های من')),
            ListTile(leading: const Icon(Icons.location_on_outlined), title: const Text('آدرس‌های من')),
            ListTile(leading: const Icon(Icons.support_agent), title: const Text('پشتیبانی')),
            const Divider(),
            ListTile(leading: const Icon(Icons.logout, color: Colors.redAccent), title: const Text('خروج از حساب'), onTap: () async { await api.logout(); setState(() => status = Future.value(false)); }),
          ],
        ]);
      },
    ),
  );
}
