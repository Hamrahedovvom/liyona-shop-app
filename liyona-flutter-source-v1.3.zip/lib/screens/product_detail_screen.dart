import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/product.dart';
import '../services/api.dart';
import '../core/theme.dart';
import '../utils/format.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;
  const ProductDetailScreen({super.key, required this.product});
  @override State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  late Future<Map<String, dynamic>> detail;
  bool adding = false;

  @override
  void initState() {
    super.initState();
    detail = api.product(widget.product.id);
  }

  Future<void> add() async {
    setState(() => adding = true);
    try {
      await api.addToCart(widget.product.id);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('محصول به سبد خرید اضافه شد')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('افزودن به سبد خرید ناموفق بود')));
    } finally {
      if (mounted) setState(() => adding = false);
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('جزئیات محصول')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: detail,
        builder: (context, s) {
          final d = s.data ?? {};
          final image = (d['image'] ?? widget.product.image).toString();
          final name = (d['name'] ?? widget.product.name).toString();
          final price = (d['sale_price'] ?? '').toString().isNotEmpty ? d['sale_price'] : (d['price'] ?? widget.product.priceHtml);
          final desc = (d['short_description'] ?? d['description'] ?? '').toString();
          return ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 110), children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(26),
              child: AspectRatio(
                aspectRatio: 1,
                child: Container(color: const Color(0xFFF8F8F8), child: CachedNetworkImage(imageUrl: image, fit: BoxFit.cover, errorWidget: (_, __, ___) => const Icon(Icons.image_not_supported_outlined, size: 64))),
              ),
            ),
            const SizedBox(height: 20),
            Text(name, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800, height: 1.5)),
            const SizedBox(height: 12),
            Text(money(price), textDirection: TextDirection.ltr, style: const TextStyle(color: LiyonaTheme.pink, fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: const Color(0xFFFFF6F9), borderRadius: BorderRadius.circular(18)),
              child: Row(children: const [Icon(Icons.verified_outlined, color: LiyonaTheme.pink), SizedBox(width: 8), Expanded(child: Text('ضمانت اصالت کالا • ارسال سریع • خرید امن'))]),
            ),
            if (desc.isNotEmpty) ...[
              const SizedBox(height: 22),
              Text('توضیحات محصول', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              Text(desc, style: const TextStyle(height: 1.9)),
            ],
          ]);
        },
      ),
      bottomSheet: SafeArea(
        child: Container(
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
          child: SizedBox(width: double.infinity, height: 54, child: FilledButton.icon(onPressed: adding ? null : add, icon: const Icon(Icons.shopping_bag_outlined), label: Text(adding ? 'در حال افزودن...' : 'افزودن به سبد خرید'))),
        ),
      ),
    ),
  );
}
