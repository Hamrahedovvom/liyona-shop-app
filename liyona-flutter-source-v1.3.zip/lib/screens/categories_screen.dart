import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../services/api.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) => SafeArea(
    child: FutureBuilder<List<dynamic>>(
      future: api.categories(),
      builder: (context, s) {
        if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (s.hasError) return const Center(child: Text('دریافت دسته‌بندی‌ها ناموفق بود'));
        final items = s.data ?? [];
        return CustomScrollView(slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 20, 18, 14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('دسته‌بندی محصولات', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                const Text('هر چیزی که دنبالش هستی، سریع‌تر پیدا کن', style: TextStyle(color: Colors.black54)),
              ]),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .95),
              delegate: SliverChildBuilderDelegate((context, i) {
                final c = items[i] as Map<String, dynamic>;
                final image = (c['image'] ?? '').toString();
                return Card(
                  clipBehavior: Clip.antiAlias,
                  child: Stack(fit: StackFit.expand, children: [
                    image.isEmpty ? Container(color: const Color(0xFFFFEEF4)) : CachedNetworkImage(imageUrl: image, fit: BoxFit.cover, errorWidget: (_, __, ___) => Container(color: const Color(0xFFFFEEF4))),
                    const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.transparent, Color(0xAA000000)], begin: Alignment.topCenter, end: Alignment.bottomCenter))),
                    Positioned(right: 12, left: 12, bottom: 12, child: Text(c['name']?.toString() ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17))),
                  ]),
                );
              }, childCount: items.length),
            ),
          ),
        ]);
      },
    ),
  );
}
