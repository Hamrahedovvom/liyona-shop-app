import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../services/api.dart';
import '../utils/format.dart';
import '../core/config.dart';
import 'package:url_launcher/url_launcher.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});
  @override State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  late Future<Map<String, dynamic>> future;
  @override void initState() { super.initState(); future = api.cart(); }
  void reload() => setState(() => future = api.cart());

  @override
  Widget build(BuildContext context) => SafeArea(
    child: FutureBuilder<Map<String, dynamic>>(
      future: future,
      builder: (context, s) {
        if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (s.hasError) return const Center(child: Text('دریافت سبد خرید ناموفق بود'));
        final cart = s.data ?? {};
        final items = List<dynamic>.from(cart['items'] ?? []);
        if (items.isEmpty) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.shopping_bag_outlined, size: 72, color: Colors.black26), const SizedBox(height: 14), Text('سبد خریدت خالیه', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)), const SizedBox(height: 6), const Text('محصول مورد علاقه‌ات رو اضافه کن') ]));
        return Column(children: [
          Padding(padding: const EdgeInsets.fromLTRB(18, 18, 18, 8), child: Row(children: [Expanded(child: Text('سبد خرید', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900))), Text('${items.length} کالا')])),
          Expanded(child: ListView.separated(padding: const EdgeInsets.all(16), itemCount: items.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (_, i) {
            final item = Map<String, dynamic>.from(items[i]);
            final images = List<dynamic>.from(item['images'] ?? []);
            final image = images.isNotEmpty ? (images.first['src'] ?? '').toString() : '';
            final prices = Map<String, dynamic>.from(item['prices'] ?? {});
            final minor = int.tryParse((prices['currency_minor_unit'] ?? 0).toString()) ?? 0;
            return Card(child: Padding(padding: const EdgeInsets.all(10), child: Row(children: [
              ClipRRect(borderRadius: BorderRadius.circular(14), child: SizedBox(width: 86, height: 86, child: image.isEmpty ? const Icon(Icons.image_outlined) : CachedNetworkImage(imageUrl: image, fit: BoxFit.cover))),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(item['name']?.toString() ?? '', maxLines: 2, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 7), Text(storeMoney(prices['price'], minor: minor), textDirection: TextDirection.ltr), const SizedBox(height: 4), Text('تعداد: ${item['quantity'] ?? 1}', style: const TextStyle(color: Colors.black54))])),
              IconButton(onPressed: () async { await api.removeCartItem(item['key'].toString()); reload(); }, icon: const Icon(Icons.delete_outline, color: Colors.redAccent)),
            ])));
          })),
          Padding(padding: const EdgeInsets.all(16), child: SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: () async { final uri = Uri.parse('${AppConfig.siteUrl}/checkout/'); await launchUrl(uri, mode: LaunchMode.externalApplication); }, child: const Text('ادامه و پرداخت امن')))),
        ]);
      },
    ),
  );
}
