# Liyona Shop v1.9.1

Corrective build based on the verified v1.8.2 API contract, carrying forward v1.9 UI/features while restoring compatible authenticated orders endpoint. Android build script recreates the host project, sets the launcher label to «فروشگاه لیونا», generates launcher icons from app_icon_v190.png, and builds release APK.
