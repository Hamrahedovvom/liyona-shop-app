import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/config.dart';
import '../models/product.dart';

class ApiService {
  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 12),
    receiveTimeout: const Duration(seconds: 20),
    headers: {'Accept': 'application/json'},
  ));
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  final Map<String, _CacheEntry> _memory = {};
  String? cartToken;

  Future<T> _cached<T>(String key, Duration ttl, Future<T> Function() loader) async {
    final hit = _memory[key];
    if (hit != null && DateTime.now().difference(hit.at) < ttl) return hit.value as T;
    final value = await loader();
    _memory[key] = _CacheEntry(value, DateTime.now());
    return value;
  }

  void invalidate(String prefix) => _memory.removeWhere((k, _) => k.startsWith(prefix));

  Future<Map<String, dynamic>> config() => _cached('config', const Duration(minutes: 10), () async {
        final r = await _dio.get('${AppConfig.customApi}/config');
        return Map<String, dynamic>.from(r.data);
      });

  Future<Map<String, dynamic>> productsPage({
    int page = 1,
    int perPage = 20,
    String? search,
    String? category,
    bool? onSale,
  }) {
    final key = 'productsPage:$page:$perPage:${search ?? ''}:${category ?? ''}:${onSale == true}';
    return _cached(key, const Duration(minutes: 3), () async {
      final r = await _dio.get('${AppConfig.customApi}/products', queryParameters: {
        'page': page,
        'per_page': perPage,
        if (search != null && search.isNotEmpty) 'search': search,
        if (category != null && category.isNotEmpty) 'category': category,
        if (onSale == true) 'on_sale': 1,
      });
      final data = Map<String, dynamic>.from(r.data);
      return {
        'items': List<dynamic>.from(data['items'] ?? [])
            .map((e) => Product.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
        'total': (data['total'] as num?)?.toInt() ?? 0,
        'pages': (data['pages'] as num?)?.toInt() ?? 1,
        'page': (data['page'] as num?)?.toInt() ?? page,
      };
    });
  }

  Future<List<Product>> products({int page = 1, int perPage = 20, String? search, String? category, bool? onSale}) async {
    final result = await productsPage(
      page: page,
      perPage: perPage,
      search: search,
      category: category,
      onSale: onSale,
    );
    return List<Product>.from(result['items'] as List);
  }

  Future<Map<String, dynamic>> product(int id) => _cached('product:$id', const Duration(minutes: 5), () async {
        final r = await _dio.get('${AppConfig.customApi}/product/$id');
        final data = Map<String, dynamic>.from(r.data);
        return Map<String, dynamic>.from(data['product'] ?? {});
      });

  Future<List<dynamic>> productReviews(int id) async {
    final r = await _dio.get('${AppConfig.customApi}/product/$id/reviews');
    return List<dynamic>.from((r.data as Map<String, dynamic>)['items'] ?? []);
  }

  Future<void> submitReview(int productId, int rating, String review) async {
    await _dio.post('${AppConfig.customApi}/product/$productId/reviews',
        data: {'rating': rating, 'review': review}, options: await _authOptions());
  }

  Future<List<dynamic>> categories({int? parent}) {
    final key = 'categories:${parent ?? 0}';
    return _cached(key, const Duration(minutes: 10), () async {
      final r = await _dio.get('${AppConfig.customApi}/categories', queryParameters: {'parent': parent ?? 0});
      final data = Map<String, dynamic>.from(r.data);
      return List<dynamic>.from(data['items'] ?? []);
    });
  }

  Future<List<dynamic>> activeCoupons() => _cached('coupons', const Duration(minutes: 5), () async {
        final r = await _dio.get('${AppConfig.customApi}/coupons');
        return List<dynamic>.from((r.data as Map<String, dynamic>)['items'] ?? []);
      });

  String normalizePhone(String raw) {
    var p = raw.replaceAll(RegExp(r'[^0-9+]'), '');
    if (p.startsWith('+98')) p = '0${p.substring(3)}';
    if (p.startsWith('98') && p.length == 12) p = '0${p.substring(2)}';
    if (p.startsWith('9') && p.length == 10) p = '0$p';
    return p;
  }

  Future<void> requestOtp(String phone) async => _dio.post('${AppConfig.customApi}/request-otp', data: {'phone': normalizePhone(phone)});

  Future<void> verifyOtp(String phone, String code) async {
    final r = await _dio.post('${AppConfig.customApi}/verify-otp', data: {'phone': normalizePhone(phone), 'code': code});
    await _storage.write(key: 'auth_token', value: r.data['token']);
  }

  Future<bool> isLoggedIn() async => (await _storage.read(key: 'auth_token'))?.isNotEmpty == true;
  Future<void> logout() => _storage.delete(key: 'auth_token');

  Future<Options> _authOptions() async {
    final t = await _storage.read(key: 'auth_token');
    return Options(headers: t == null ? {} : {'Authorization': 'Bearer $t'});
  }

  Future<Map<String, dynamic>> me() async {
    final r = await _dio.get('${AppConfig.customApi}/me', options: await _authOptions());
    return Map<String, dynamic>.from(r.data['user'] ?? {});
  }

  Future<void> updateMe(Map<String, dynamic> data) async {
    await _dio.post('${AppConfig.customApi}/me', data: data, options: await _authOptions());
  }

  Future<Map<String, dynamic>> trackOrder(String id, String phone) async {
    final r = await _dio.post('${AppConfig.customApi}/track-order', data: {'order_id': id, 'phone': phone});
    return Map<String, dynamic>.from(r.data);
  }

  Future<List<dynamic>> myOrders() async {
    final r = await _dio.get(
      '${AppConfig.customApi}/me/orders',
      options: await _authOptions(),
    );
    final data = Map<String, dynamic>.from(r.data);
    return List<dynamic>.from(data['items'] ?? []);
  }

  Future<String?> _storedCartToken() async => cartToken ??= await _storage.read(key: 'cart_token');

  Future<void> _saveCartToken(Response r) async {
    final v = r.headers.value('Cart-Token');
    if (v != null && v.isNotEmpty) {
      cartToken = v;
      await _storage.write(key: 'cart_token', value: v);
    }
  }

  Future<Options> _cartOptions() async {
    final t = await _storedCartToken();
    return Options(headers: {if (t != null && t.isNotEmpty) 'Cart-Token': t});
  }

  Future<Map<String, dynamic>> cart() async {
    final r = await _dio.get('${AppConfig.storeApi}/cart', options: await _cartOptions());
    await _saveCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }

  Future<Map<String, dynamic>> addToCart(int productId, {int quantity = 1, List<Map<String, String>> variation = const []}) async {
    if ((await _storedCartToken()) == null) await cart();
    final body = <String, dynamic>{'id': productId, 'quantity': quantity};
    if (variation.isNotEmpty) body['variation'] = variation;
    final r = await _dio.post('${AppConfig.storeApi}/cart/add-item', data: body, options: await _cartOptions());
    await _saveCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }

  Future<Map<String, dynamic>> updateCartItem(String key, int quantity) async {
    final r = await _dio.post('${AppConfig.storeApi}/cart/update-item', data: {'key': key, 'quantity': quantity}, options: await _cartOptions());
    await _saveCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }

  Future<Map<String, dynamic>> removeCartItem(String key) async {
    final r = await _dio.post('${AppConfig.storeApi}/cart/remove-item', data: {'key': key}, options: await _cartOptions());
    await _saveCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }

  Future<Map<String, dynamic>> applyCoupon(String code) async {
    final r = await _dio.post('${AppConfig.storeApi}/cart/apply-coupon', data: {'code': code}, options: await _cartOptions());
    await _saveCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }

  Future<Map<String, dynamic>> selectShippingRate(String packageId, String rateId) async {
    final r = await _dio.post('${AppConfig.storeApi}/cart/select-shipping-rate',
        data: {'package_id': packageId, 'rate_id': rateId}, options: await _cartOptions());
    await _saveCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }


  Future<Map<String, dynamic>> updateCustomer({
    required Map<String, dynamic> billing,
    required Map<String, dynamic> shipping,
  }) async {
    final r = await _dio.post(
      '${AppConfig.storeApi}/cart/update-customer',
      data: {'billing_address': billing, 'shipping_address': shipping},
      options: await _cartOptions(),
    );
    await _saveCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }

  Future<Map<String, dynamic>> checkoutInfo() async {
    final r = await _dio.get('${AppConfig.storeApi}/checkout', options: await _cartOptions());
    await _saveCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }

  Future<Map<String, dynamic>> checkout({
    required Map<String, dynamic> billing,
    required Map<String, dynamic> shipping,
    required String paymentMethod,
  }) async {
    final r = await _dio.post('${AppConfig.storeApi}/checkout',
        data: {
          'billing_address': billing,
          'shipping_address': shipping,
          'payment_method': paymentMethod,
          'payment_data': <dynamic>[],
        },
        options: await _cartOptions());
    await _saveCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }

  Future<Map<String, dynamic>> appPopup() => _cached('app-popup', const Duration(minutes: 2), () async {
    final r = await _dio.get('${AppConfig.customApi}/app-popup');
    return Map<String, dynamic>.from(r.data is Map ? r.data : <String,dynamic>{});
  });

  Future<List<Map<String, dynamic>>> paymentMethods() async {
    try {
      final r = await _dio.get('${AppConfig.customApi}/payment-methods', options: await _authOptions());
      final data = Map<String, dynamic>.from(r.data);
      return List<dynamic>.from(data['items'] ?? []).map((e) => Map<String,dynamic>.from(e)).toList();
    } catch (_) {
      final data = await checkoutInfo();
      return List<dynamic>.from(data['payment_methods'] ?? []).map((e) {
        if (e is Map) return Map<String,dynamic>.from(e);
        return <String,dynamic>{'id': e.toString(), 'title': e.toString()};
      }).toList();
    }
  }

  Future<Map<String, dynamic>> orderStatus(int id) async {
    final r = await _dio.get('${AppConfig.customApi}/me/orders/$id', options: await _authOptions());
    return Map<String, dynamic>.from(r.data);
  }

  Future<List<Map<String, dynamic>>> savedForLater() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList('saved_for_later') ?? [];
    return raw.map((e) => Map<String, dynamic>.from(jsonDecode(e))).toList();
  }

  Future<void> saveForLater(Map<String, dynamic> item) async {
    final p = await SharedPreferences.getInstance();
    final items = await savedForLater();
    final key = item['key']?.toString();
    if (key != null && !items.any((e) => e['key']?.toString() == key)) items.add(item);
    await p.setStringList('saved_for_later', items.map(jsonEncode).toList());
  }
}

class _CacheEntry {
  final dynamic value;
  final DateTime at;
  _CacheEntry(this.value, this.at);
}

final api = ApiService();
