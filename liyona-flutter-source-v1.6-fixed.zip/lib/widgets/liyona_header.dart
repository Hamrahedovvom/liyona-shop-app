import 'package:flutter/material.dart';
import '../core/theme.dart';

class LiyonaHeader extends StatelessWidget implements PreferredSizeWidget {
  final VoidCallback? onBack;
  final VoidCallback? onCart;
  final VoidCallback? onAccount;
  final int cartCount;
  const LiyonaHeader({
    super.key,
    this.onBack,
    this.onCart,
    this.onAccount,
    this.cartCount = 0,
  });

  @override
  Size get preferredSize => const Size.fromHeight(62);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      automaticallyImplyLeading: false,
      centerTitle: true,
      elevation: 0,
      scrolledUnderElevation: 0,
      backgroundColor: Colors.white,
      surfaceTintColor: Colors.white,
      leading: onBack != null
          ? IconButton(
              onPressed: onBack,
              icon: const Icon(Icons.arrow_forward_ios_rounded, size: 20),
            )
          : IconButton(
              onPressed: onAccount,
              icon: const Icon(Icons.person_outline_rounded),
            ),
      title: Container(
        height: 46,
        padding: const EdgeInsets.symmetric(horizontal: 6),
        color: Colors.white,
        child: Image.asset(
          'assets/images/liyona_logo.jpg',
          fit: BoxFit.contain,
          filterQuality: FilterQuality.high,
        ),
      ),
      actions: [
        Stack(
          clipBehavior: Clip.none,
          children: [
            IconButton(
              onPressed: onCart,
              icon: const Icon(Icons.shopping_bag_outlined),
            ),
            if (cartCount > 0)
              Positioned(
                top: 8,
                right: 3,
                child: Container(
                  constraints: const BoxConstraints(minWidth: 17, minHeight: 17),
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  decoration: const BoxDecoration(
                    color: LiyonaTheme.pink,
                    shape: BoxShape.circle,
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    '$cartCount',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 9,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(width: 4),
      ],
    );
  }
}
