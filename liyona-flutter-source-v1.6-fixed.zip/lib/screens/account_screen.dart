import 'package:flutter/material.dart';
import '../services/api.dart';
import '../core/theme.dart';
import '../widgets/contact_sheet.dart';
import 'login_screen.dart';

class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});
  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  Future<bool> status = api.isLoggedIn();

  Future<void> login() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    setState(() => status = api.isLoggedIn());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: FutureBuilder<bool>(
        future: status,
        builder: (context, s) {
          final logged = s.data == true;
          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 120),
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFFFFE3EE), Color(0xFFFFF7FA)]),
                  borderRadius: BorderRadius.circular(26),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 34,
                      backgroundColor: Colors.white,
                      child: Icon(logged ? Icons.person : Icons.login_rounded, size: 35, color: LiyonaTheme.pink),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(logged ? 'حساب لیونا' : 'ورود به حساب', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 4),
                          Text(logged ? 'مدیریت حساب و امکانات اختصاصی' : 'ورود و عضویت با شماره موبایل', style: const TextStyle(color: Colors.black54)),
                        ],
                      ),
                    ),
                    if (!logged) FilledButton(onPressed: login, child: const Text('ورود')),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              const Text('خدمات حساب', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              AccountTile(
                icon: Icons.local_shipping_outlined,
                title: 'پیگیری سفارش',
                subtitle: 'با شماره سفارش یا موبایل',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TrackOrderScreen())),
              ),
              AccountTile(
                icon: Icons.local_offer_outlined,
                title: 'کدهای تخفیف فعال',
                subtitle: 'پیشنهادهای قابل استفاده در لیونا',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CouponsScreen())),
              ),
              AccountTile(
                icon: Icons.support_agent,
                title: 'تماس با ما',
                subtitle: 'تلفن، واتساپ، تلگرام، ایمیل و اینستاگرام',
                onTap: () => showContactSheet(context),
              ),
              AccountTile(
                icon: Icons.info_outline,
                title: 'درباره ما',
                subtitle: 'درباره فروشگاه اینترنتی لیونا',
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutScreen())),
              ),
              AccountTile(
                icon: Icons.phone_android_outlined,
                title: 'اطلاعات اپ',
                subtitle: 'نسخه 1.5.0',
                onTap: () => showAboutDialog(
                  context: context,
                  applicationName: 'Liyona Shop',
                  applicationVersion: '1.5.0',
                  children: const [Text('اپلیکیشن رسمی فروشگاه لیونا')],
                ),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: const Color(0xFFF7F5F7), borderRadius: BorderRadius.circular(18)),
                child: const Column(
                  children: [
                    Text('طراحی و توسعه توسط', style: TextStyle(color: Colors.black54)),
                    SizedBox(height: 4),
                    Text('علی فخیره', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                  ],
                ),
              ),
              if (logged) ...[
                const SizedBox(height: 12),
                TextButton.icon(
                  onPressed: () async {
                    await api.logout();
                    setState(() => status = Future.value(false));
                  },
                  icon: const Icon(Icons.logout, color: Colors.redAccent),
                  label: const Text('خروج از حساب', style: TextStyle(color: Colors.redAccent)),
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}

class AccountTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const AccountTile({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 9),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(19),
          border: Border.all(color: const Color(0xFFF0E8EC)),
        ),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          leading: CircleAvatar(backgroundColor: const Color(0xFFFFEAF1), child: Icon(icon, color: LiyonaTheme.pink)),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_left),
          onTap: onTap,
        ),
      );
}

class TrackOrderScreen extends StatefulWidget {
  const TrackOrderScreen({super.key});
  @override
  State<TrackOrderScreen> createState() => _TrackOrderScreenState();
}

class _TrackOrderScreenState extends State<TrackOrderScreen> {
  final id = TextEditingController();
  final phone = TextEditingController();
  Map<String, dynamic>? result;
  bool busy = false;

  @override
  void dispose() {
    id.dispose();
    phone.dispose();
    super.dispose();
  }

  Future<void> go() async {
    setState(() => busy = true);
    try {
      result = await api.trackOrder(id.text.trim(), phone.text.trim());
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('سفارش پیدا نشد یا اطلاعات صحیح نیست')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('پیگیری سفارش')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('شماره سفارش یا موبایل را وارد کن', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            TextField(controller: id, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'شماره سفارش (اختیاری)')),
            const SizedBox(height: 10),
            TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره موبایل')),
            const SizedBox(height: 14),
            FilledButton(onPressed: busy ? null : go, child: Text(busy ? 'در حال بررسی...' : 'پیگیری سفارش')),
            if (result != null) ...[
              const SizedBox(height: 18),
              ...List<dynamic>.from(result!['items'] ?? []).map((e) {
                final m = Map<String, dynamic>.from(e);
                return Card(
                  child: ListTile(
                    title: Text('سفارش #${m['number'] ?? m['id']}'),
                    subtitle: Text((m['status_label'] ?? m['status'] ?? '').toString()),
                    trailing: Text('${m['total'] ?? ''} ${m['currency'] ?? ''}'),
                  ),
                );
              }),
            ],
          ],
        ),
      );
}

class CouponsScreen extends StatelessWidget {
  const CouponsScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('کدهای تخفیف فعال')),
        body: FutureBuilder<List<dynamic>>(
          future: api.activeCoupons(),
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
            final items = s.data ?? [];
            if (items.isEmpty) return const Center(child: Text('فعلاً کد تخفیف فعالی نیست'));
            return ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) {
                final c = Map<String, dynamic>.from(items[i]);
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                (c['title'] ?? 'تخفیف لیونا').toString(),
                                style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(color: const Color(0xFFFFE4EE), borderRadius: BorderRadius.circular(99)),
                              child: Text((c['code'] ?? '').toString(), style: const TextStyle(color: LiyonaTheme.pink, fontWeight: FontWeight.w900)),
                            ),
                          ],
                        ),
                        if ((c['description'] ?? '').toString().isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text((c['description'] ?? '').toString()),
                        ],
                        if ((c['expires'] ?? '').toString().isNotEmpty) ...[
                          const SizedBox(height: 6),
                          Text('اعتبار تا: ${c['expires']}', style: const TextStyle(color: Colors.black54, fontSize: 12)),
                        ],
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      );
}

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('درباره لیونا')),
        body: ListView(
          padding: const EdgeInsets.all(22),
          children: [
            Image.asset('assets/images/liyona_logo.jpg', height: 80),
            const SizedBox(height: 20),
            const Text('فروشگاه اینترنتی لیونا', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            const Text(
              'لیونا یک فروشگاه اینترنتی با تمرکز بر تجربه خرید ساده، سریع و مطمئن است. محصولات، سفارش و پشتیبانی از طریق سایت و اپلیکیشن به‌صورت یکپارچه در دسترس هستند.',
              style: TextStyle(height: 2),
            ),
            const SizedBox(height: 20),
            const Text('طراحی و توسعه توسط علی فخیره', style: TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
      );
}
