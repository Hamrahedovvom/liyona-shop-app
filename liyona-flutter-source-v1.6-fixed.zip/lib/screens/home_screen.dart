import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/api.dart';
import '../models/product.dart';
import '../widgets/app_loader.dart';
import '../widgets/explore_grid.dart';
import '../core/theme.dart';
import 'category_products_screen.dart';

class HomeScreen extends StatefulWidget {
  final ValueChanged<int> onSelectTab;
  const HomeScreen({super.key, required this.onSelectTab});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ScrollController controller = ScrollController();
  final TextEditingController search = TextEditingController();
  final PageController bannerController = PageController(viewportFraction: .92);
  late Future<List<dynamic>> cats;
  late Future<Map<String, dynamic>> config;
  Timer? timer;
  bool showTop = false;
  int bannerIndex = 0;

  @override
  void initState() {
    super.initState();
    cats = api.categories(parent: 0);
    config = api.config();
    controller.addListener(() {
      final next = controller.offset > 500;
      if (next != showTop && mounted) setState(() => showTop = next);
    });
    timer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (!mounted || !bannerController.hasClients) return;
      final c = await config;
      final items = List<dynamic>.from(c['banners'] ?? []);
      if (items.length < 2) return;
      bannerIndex = (bannerIndex + 1) % items.length;
      bannerController.animateToPage(
        bannerIndex,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeOutCubic,
      );
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    controller.dispose();
    search.dispose();
    bannerController.dispose();
    super.dispose();
  }

  Future<void> refresh() async {
    api.invalidate('products');
    api.invalidate('productsPage');
    api.invalidate('categories');
    api.invalidate('config');
    setState(() {
      cats = api.categories(parent: 0);
      config = api.config();
    });
    await cats;
    await config;
  }

  Future<void> openLink(String raw) async {
    final value = raw.trim();
    if (value.isEmpty) return;
    final uri = Uri.tryParse(value.startsWith('http') ? value : 'https://$value');
    if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Stack(
        children: [
          RefreshIndicator(
            onRefresh: refresh,
            child: CustomScrollView(
              controller: controller,
              slivers: [
                SliverAppBar(
                  pinned: true,
                  floating: true,
                  snap: true,
                  expandedHeight: 122,
                  toolbarHeight: 62,
                  backgroundColor: Colors.white,
                  surfaceTintColor: Colors.white,
                  scrolledUnderElevation: 0,
                  centerTitle: true,
                  title: SizedBox(
                    height: 46,
                    child: Image.asset('assets/images/liyona_logo.jpg', fit: BoxFit.contain),
                  ),
                  leading: IconButton(
                    onPressed: () => widget.onSelectTab(3),
                    icon: const Icon(Icons.person_outline_rounded),
                  ),
                  actions: [
                    IconButton(
                      onPressed: () => widget.onSelectTab(2),
                      icon: const Icon(Icons.shopping_bag_outlined),
                    ),
                  ],
                  flexibleSpace: FlexibleSpaceBar(
                    background: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 68, 16, 8),
                      child: TextField(
                        controller: search,
                        textInputAction: TextInputAction.search,
                        onSubmitted: (q) {
                          if (q.trim().isEmpty) return;
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => SearchProductsScreen(query: q.trim()),
                            ),
                          );
                        },
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search_rounded),
                          hintText: 'جستجو بین محصولات لیونا...',
                        ),
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(child: _Stories(config: config, onTap: openLink)),
                SliverToBoxAdapter(
                  child: _Banners(
                    future: config,
                    controller: bannerController,
                    onPageChanged: (v) => bannerIndex = v,
                    onTap: openLink,
                  ),
                ),
                SliverToBoxAdapter(child: _CategoryStrip(cats: cats)),
                SliverToBoxAdapter(
                  child: ExploreSection(
                    title: 'جدیدترین محصولات',
                    future: api.products(perPage: 9),
                    onAll: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const AllProductsScreen(title: 'جدیدترین محصولات')),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: ExploreSection(
                    title: 'شگفت‌انگیزهای لیونا',
                    future: api.products(perPage: 9, onSale: true),
                    hideWhenEmpty: true,
                    accent: true,
                    onAll: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const AllProductsScreen(title: 'شگفت‌انگیزهای لیونا', onSale: true)),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: FutureBuilder<List<dynamic>>(
                    future: cats,
                    builder: (context, s) {
                      final items = s.data ?? [];
                      return Column(
                        children: items.map((raw) {
                          final c = Map<String, dynamic>.from(raw);
                          final name = (c['name'] ?? '').toString();
                          final slug = (c['slug'] ?? '').toString();
                          return ExploreSection(
                            title: name,
                            future: api.products(category: slug, perPage: 9),
                            hideWhenEmpty: true,
                            onAll: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => CategoryProductsScreen(name: name, slug: slug),
                              ),
                            ),
                          );
                        }).toList(),
                      );
                    },
                  ),
                ),
                const SliverToBoxAdapter(child: SizedBox(height: 120)),
              ],
            ),
          ),
          if (showTop)
            Positioned(
              left: 16,
              bottom: 18,
              child: FloatingActionButton.small(
                heroTag: 'top-home',
                onPressed: () => controller.animateTo(
                  0,
                  duration: const Duration(milliseconds: 450),
                  curve: Curves.easeOutCubic,
                ),
                child: const Icon(Icons.keyboard_arrow_up),
              ),
            ),
        ],
      ),
    );
  }
}

class _Stories extends StatelessWidget {
  final Future<Map<String, dynamic>> config;
  final ValueChanged<String> onTap;
  const _Stories({required this.config, required this.onTap});

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: config,
        builder: (context, s) {
          final items = List<dynamic>.from(s.data?['stories'] ?? []);
          if (items.isEmpty) return const SizedBox(height: 8);
          return SizedBox(
            height: 116,
            child: ListView.separated(
              reverse: true,
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (_, i) {
                final item = Map<String, dynamic>.from(items[i]);
                final image = (item['image'] ?? '').toString();
                return InkWell(
                  borderRadius: BorderRadius.circular(48),
                  onTap: () => onTap((item['link'] ?? '').toString()),
                  child: SizedBox(
                    width: 78,
                    child: Column(
                      children: [
                        Container(
                          width: 70,
                          height: 70,
                          padding: const EdgeInsets.all(3),
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(colors: [LiyonaTheme.pink, Color(0xFF5976FF)]),
                          ),
                          child: CircleAvatar(
                            backgroundColor: Colors.white,
                            backgroundImage: image.isNotEmpty ? CachedNetworkImageProvider(image) : null,
                            child: image.isEmpty ? const Icon(Icons.auto_stories_outlined) : null,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          (item['title'] ?? '').toString(),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          );
        },
      );
}

class _Banners extends StatelessWidget {
  final Future<Map<String, dynamic>> future;
  final PageController controller;
  final ValueChanged<int> onPageChanged;
  final ValueChanged<String> onTap;
  const _Banners({required this.future, required this.controller, required this.onPageChanged, required this.onTap});

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: future,
        builder: (context, s) {
          final items = List<dynamic>.from(s.data?['banners'] ?? []);
          if (items.isEmpty) return const SizedBox.shrink();
          return SizedBox(
            height: 190,
            child: PageView.builder(
              controller: controller,
              onPageChanged: onPageChanged,
              itemCount: items.length,
              itemBuilder: (_, i) {
                final item = Map<String, dynamic>.from(items[i]);
                final image = (item['image'] ?? '').toString();
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 8),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(24),
                    onTap: () => onTap((item['link'] ?? '').toString()),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: image.isEmpty
                          ? const ColoredBox(color: Color(0xFFFFE7EF))
                          : CachedNetworkImage(imageUrl: image, fit: BoxFit.cover),
                    ),
                  ),
                );
              },
            ),
          );
        },
      );
}

class _CategoryStrip extends StatelessWidget {
  final Future<List<dynamic>> cats;
  const _CategoryStrip({required this.cats});

  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
        future: cats,
        builder: (context, s) {
          final items = s.data ?? [];
          if (items.isEmpty) return const SizedBox.shrink();
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 14, 16, 8),
                child: Text('دسته‌بندی‌ها', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              ),
              SizedBox(
                height: 120,
                child: ListView.separated(
                  reverse: true,
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (_, i) {
                    final c = Map<String, dynamic>.from(items[i]);
                    final image = (c['image'] ?? '').toString();
                    return InkWell(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => CategoryProductsScreen(
                            name: (c['name'] ?? '').toString(),
                            slug: (c['slug'] ?? '').toString(),
                          ),
                        ),
                      ),
                      child: SizedBox(
                        width: 86,
                        child: Column(
                          children: [
                            CircleAvatar(
                              radius: 35,
                              backgroundColor: const Color(0xFFFFE7EF),
                              backgroundImage: image.isNotEmpty ? CachedNetworkImageProvider(image) : null,
                              child: image.isEmpty ? const Icon(Icons.category_outlined) : null,
                            ),
                            const SizedBox(height: 5),
                            Text(
                              (c['name'] ?? '').toString(),
                              maxLines: 2,
                              textAlign: TextAlign.center,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      );
}

class SectionHeader extends StatelessWidget {
  final String title;
  final VoidCallback onAll;
  final bool light;
  const SectionHeader(this.title, this.onAll, {super.key, this.light = false});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
        child: Row(
          children: [
            Expanded(
              child: Text(
                title,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: light ? Colors.white : null),
              ),
            ),
            TextButton(
              onPressed: onAll,
              child: Text('مشاهده همه', style: TextStyle(color: light ? Colors.white : null)),
            ),
          ],
        ),
      );
}

class ExploreSection extends StatelessWidget {
  final String title;
  final Future<List<Product>> future;
  final VoidCallback onAll;
  final bool hideWhenEmpty;
  final bool accent;
  const ExploreSection({
    super.key,
    required this.title,
    required this.future,
    required this.onAll,
    this.hideWhenEmpty = false,
    this.accent = false,
  });

  @override
  Widget build(BuildContext context) => FutureBuilder<List<Product>>(
        future: future,
        builder: (context, s) {
          if (s.connectionState != ConnectionState.done) {
            return Column(children: [SectionHeader(title, onAll, light: accent), const ProductSkeleton()]);
          }
          final items = s.data ?? [];
          if (items.isEmpty && hideWhenEmpty) return const SizedBox.shrink();
          final body = Column(
            children: [
              SectionHeader(title, onAll, light: accent),
              if (items.isEmpty)
                const Padding(padding: EdgeInsets.all(24), child: Text('محصولی برای نمایش نیست'))
              else
                ExploreGrid(products: items.take(9).toList()),
              const SizedBox(height: 8),
            ],
          );
          if (!accent) return body;
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 10),
            padding: const EdgeInsets.only(bottom: 8),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [Color(0xFFE60064), Color(0xFFFF4D91)]),
            ),
            child: body,
          );
        },
      );
}

class SearchProductsScreen extends StatelessWidget {
  final String query;
  const SearchProductsScreen({super.key, required this.query});

  @override
  Widget build(BuildContext context) => _PagedProductsScreen(title: 'نتایج جستجو', search: query);
}

class AllProductsScreen extends StatelessWidget {
  final String title;
  final bool onSale;
  const AllProductsScreen({super.key, required this.title, this.onSale = false});

  @override
  Widget build(BuildContext context) => _PagedProductsScreen(title: title, onSale: onSale);
}

class _PagedProductsScreen extends StatefulWidget {
  final String title;
  final String? search;
  final bool onSale;
  const _PagedProductsScreen({required this.title, this.search, this.onSale = false});
  @override
  State<_PagedProductsScreen> createState() => _PagedProductsScreenState();
}

class _PagedProductsScreenState extends State<_PagedProductsScreen> {
  int page = 1;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: FutureBuilder<Map<String, dynamic>>(
        future: api.productsPage(page: page, perPage: 50, search: widget.search, onSale: widget.onSale),
        builder: (context, s) {
          if (s.connectionState != ConnectionState.done) return const LiyonaLoader();
          final data = s.data ?? {};
          final items = List<Product>.from(data['items'] ?? const <Product>[]);
          final pages = (data['pages'] as int?) ?? 1;
          if (items.isEmpty) return const Center(child: Text('محصولی پیدا نشد'));
          return Column(
            children: [
              Expanded(child: ExploreGrid(products: items, shrinkWrap: false, padding: EdgeInsets.zero)),
              _Pagination(page: page, pages: pages, onChanged: (p) => setState(() => page = p)),
            ],
          );
        },
      ),
    );
  }
}

class _Pagination extends StatelessWidget {
  final int page;
  final int pages;
  final ValueChanged<int> onChanged;
  const _Pagination({required this.page, required this.pages, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    if (pages <= 1) return const SizedBox.shrink();
    return SafeArea(
      top: false,
      child: Container(
        color: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(onPressed: page > 1 ? () => onChanged(page - 1) : null, icon: const Icon(Icons.chevron_right)),
            Text('صفحه $page از $pages', style: const TextStyle(fontWeight: FontWeight.w800)),
            IconButton(onPressed: page < pages ? () => onChanged(page + 1) : null, icon: const Icon(Icons.chevron_left)),
          ],
        ),
      ),
    );
  }
}
