# Liyona Shop v1.10.0

Build base: stable v1.9.2 Fixed / WooCommerce-compatible API.

Changes in this package include product-page RTL fixes, product-header search, variable-product selector compatibility, WooCommerce sale/stock metadata, amazing-offer banner, richer customer reviews, coupon copy action, removal of incomplete save-for-later cart action, and preserved checkout/home/admin integration.
