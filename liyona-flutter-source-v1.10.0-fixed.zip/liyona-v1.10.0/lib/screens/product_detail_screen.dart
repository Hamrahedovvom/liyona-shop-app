import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/product.dart';
import '../services/api.dart';
import '../core/theme.dart';
import '../utils/format.dart';
import '../widgets/app_loader.dart';
import '../widgets/html_content.dart';
import '../widgets/liyona_header.dart';
import 'cart_screen.dart';
import 'category_products_screen.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;
  const ProductDetailScreen({super.key, required this.product});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  late Future<Map<String, dynamic>> detail;
  final PageController galleryController = PageController();
  int imageIndex = 0;
  int qty = 1;
  bool adding = false;
  final Map<String, String> selected = {};

  @override
  void initState() {
    super.initState();
    detail = api.product(widget.product.id);
  }

  @override
  void dispose() {
    galleryController.dispose();
    super.dispose();
  }

  List<String> images(Map<String, dynamic> d) {
    final out = <String>[];
    final main = (d['image'] ?? '').toString();
    if (main.isNotEmpty) out.add(main);
    for (final e in List<dynamic>.from(d['gallery'] ?? [])) {
      final u = e.toString();
      if (u.isNotEmpty && !out.contains(u)) out.add(u);
    }
    return out;
  }

  String attrSlug(Map<String, dynamic> a) => _normAttr((a['slug'] ?? a['name'] ?? '').toString());
  String _normAttr(String v) => v.toLowerCase().trim().replaceFirst(RegExp(r'^attribute_'), '');
  String _normValue(String v) => Uri.decodeComponent(v).toLowerCase().trim();

  List<Map<String, String>> attrOptions(Map<String, dynamic> a) {
    final result = <Map<String, String>>[];
    for (final raw in List<dynamic>.from(a['options'] ?? [])) {
      if (raw is Map) {
        final m = Map<String, dynamic>.from(raw);
        final label = (m['label'] ?? m['name'] ?? m['value'] ?? '').toString();
        final value = (m['value'] ?? m['slug'] ?? label).toString();
        if (label.isNotEmpty) result.add({'label': label, 'value': value});
      } else {
        final value = raw.toString();
        if (value.isNotEmpty) result.add({'label': value, 'value': value});
      }
    }
    return result;
  }

  bool optionAvailable(Map<String, dynamic> d, String attr, String value) {
    final trial = Map<String, String>.from(selected)..[attr] = value;
    for (final raw in List<dynamic>.from(d['variations'] ?? [])) {
      final v = Map<String, dynamic>.from(raw);
      if (v['in_stock'] == false) continue;
      var ok = true;
      for (final rawAttr in List<dynamic>.from(v['attributes'] ?? [])) {
        final a = Map<String, dynamic>.from(rawAttr);
        final slug = _normAttr((a['slug'] ?? a['name'] ?? '').toString());
        final vv = _normValue((a['value'] ?? a['option'] ?? '').toString());
        final chosen = trial[slug];
        if (vv.isNotEmpty && chosen != null && chosen.isNotEmpty && _normValue(chosen) != vv) { ok = false; break; }
      }
      if (ok) return true;
    }
    return false;
  }

  Map<String, dynamic>? matchedVariation(Map<String, dynamic> d) {
    final attrs = List<dynamic>.from(d['attributes'] ?? [])
        .map((e) => Map<String, dynamic>.from(e))
        .where((a) => a['variation'] == true)
        .toList();
    for (final a in attrs) {
      if ((selected[attrSlug(a)] ?? '').isEmpty) return null;
    }

    for (final raw in List<dynamic>.from(d['variations'] ?? [])) {
      final v = Map<String, dynamic>.from(raw);
      var ok = true;
      for (final rawAttr in List<dynamic>.from(v['attributes'] ?? [])) {
        final a = Map<String, dynamic>.from(rawAttr);
        final slug = _normAttr((a['slug'] ?? a['name'] ?? '').toString());
        final value = _normValue((a['value'] ?? a['option'] ?? '').toString());
        if (value.isNotEmpty && _normValue(selected[slug] ?? '') != value) {
          ok = false;
          break;
        }
      }
      if (ok) return v;
    }
    return null;
  }

  Future<void> add(Map<String, dynamic> d) async {
    final attrs = List<dynamic>.from(d['attributes'] ?? [])
        .map((e) => Map<String, dynamic>.from(e))
        .where((a) => a['variation'] == true)
        .toList();

    for (final a in attrs) {
      final slug = attrSlug(a);
      if ((selected[slug] ?? '').isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('لطفاً ${a['name'] ?? 'گزینه محصول'} را انتخاب کنید')),
        );
        return;
      }
    }

    final isVariable = (d['type'] ?? '') == 'variable';
    final variation = isVariable ? matchedVariation(d) : null;
    if (isVariable && variation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('این ترکیب از گزینه‌ها موجود نیست')),
      );
      return;
    }
    if (variation != null && variation['in_stock'] == false) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('این گزینه در حال حاضر ناموجود است')),
      );
      return;
    }

    setState(() => adding = true);
    try {
      final id = variation == null ? widget.product.id : (variation['id'] as num).toInt();
      final variationPayload = attrs.map((a) {
        final slug = attrSlug(a);
        return {'attribute': slug, 'value': selected[slug] ?? ''};
      }).toList();
      await api.addToCart(id, quantity: qty, variation: variationPayload);
      if (!mounted) return;
      await _showAddedDialog(d);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('افزودن به سبد خرید ناموفق بود\n$e')),
      );
    } finally {
      if (mounted) setState(() => adding = false);
    }
  }

  Future<void> _showAddedDialog(Map<String, dynamic> d) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => Container(
        margin: const EdgeInsets.all(12),
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 20),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: const BoxDecoration(color: Color(0xFFFFE4EE), shape: BoxShape.circle),
                child: const Icon(Icons.check_rounded, color: LiyonaTheme.pink, size: 32),
              ),
              const SizedBox(height: 10),
              const Text('به سبد خرید اضافه شد', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text(
                (d['name'] ?? widget.product.name).toString(),
                maxLines: 2,
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
              ),
              if (selected.isNotEmpty) ...[
                const SizedBox(height: 6),
                Text(
                  selected.values.join(' • '),
                  style: const TextStyle(color: Colors.black54, fontWeight: FontWeight.w700),
                ),
              ],
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(sheetContext),
                      child: const Text('ادامه خرید'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton(
                      onPressed: () {
                        Navigator.pop(sheetContext);
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen()));
                      },
                      child: const Text('رفتن به سبد خرید'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> showVariantSheet(Map<String, dynamic> d) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (sheetContext) => StatefulBuilder(builder: (context, setSheet) {
        final attrs = List<dynamic>.from(d['attributes'] ?? []).map((e)=>Map<String,dynamic>.from(e)).where((a)=>a['variation']==true).toList();
        final v = matchedVariation(d);
        final price = (v?['price'] ?? d['price'] ?? '').toString();
        final stock = (v?['stock_quantity'] ?? '').toString();
        return Directionality(textDirection: TextDirection.rtl, child: SafeArea(top:false, child: Padding(
          padding: EdgeInsets.fromLTRB(18, 0, 18, 18 + MediaQuery.of(context).viewInsets.bottom),
          child: SingleChildScrollView(child: Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
            const Text('انتخاب گزینه‌ها',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),
            const SizedBox(height:12),
            ...attrs.map((a){final slug=attrSlug(a);return Padding(padding:const EdgeInsets.only(bottom:14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text((a['name']??'').toString(),style:const TextStyle(fontWeight:FontWeight.w900)),const SizedBox(height:8),Wrap(spacing:8,runSpacing:8,children:attrOptions(a).map((o){final value=o['value']??'';final available=optionAvailable(d,slug,value);final chosen=selected[slug]==value;return ChoiceChip(label:Row(mainAxisSize:MainAxisSize.min,children:[if(!available)...[const Icon(Icons.close,size:16,color:Colors.redAccent),const SizedBox(width:4)],Text(o['label']??value)]),selected:chosen,onSelected:available?(x){setState(()=>selected[slug]=value);setSheet((){});}:null);}).toList())]));}),
            if(v!=null) Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:const Color(0xFFF0FAF3),borderRadius:BorderRadius.circular(14)),child:Text(v['in_stock']==false?'ناموجود':(stock.isNotEmpty?'$stock عدد موجود در انبار':'موجود در انبار'),style:TextStyle(color:v['in_stock']==false?Colors.red:Colors.green.shade800,fontWeight:FontWeight.w900))),
            const SizedBox(height:12),
            Row(children:[const Text('تعداد',style:TextStyle(fontWeight:FontWeight.w900)),const Spacer(),IconButton(onPressed:qty>1?(){setState(()=>qty--);setSheet((){});}:null,icon:const Icon(Icons.remove_circle_outline)),Text('$qty',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),IconButton(onPressed:(){setState(()=>qty++);setSheet((){});},icon:const Icon(Icons.add_circle_outline))]),
            const SizedBox(height:8),
            Row(children:[Expanded(child:Text(money(price),style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:LiyonaTheme.pink))),Expanded(flex:2,child:FilledButton.icon(onPressed:adding||v==null||v['in_stock']==false?null:()async{Navigator.pop(sheetContext);await add(d);},icon:const Icon(Icons.shopping_bag_outlined),label:const Text('افزودن به سبد خرید')))]),
          ])),
        )));
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: LiyonaHeader(
          onBack: () => Navigator.pop(context),
          onSearch: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProductSearchPage())),
          onCart: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())),
        ),
        body: FutureBuilder<Map<String, dynamic>>(
          future: detail,
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) return const LiyonaLoader();
            if (s.hasError) return const Center(child: Text('دریافت اطلاعات محصول ناموفق بود'));

            final d = s.data ?? {};
            final gallery = images(d);
            final attrs = List<dynamic>.from(d['attributes'] ?? [])
                .map((e) => Map<String, dynamic>.from(e))
                .where((a) => a['variation'] == true)
                .toList();
            final variation = matchedVariation(d);
            final shownPrice = (variation?['price'] ?? d['price'] ?? '').toString();
            final desc = (d['description'] ?? '').toString();
            final short = (d['short_description'] ?? '').toString();
            final cats = List<dynamic>.from(d['categories'] ?? []);
            final tags = List<dynamic>.from(d['tags'] ?? []);
            final salePrice = (d['sale_price'] ?? '').toString();
            final regularPrice = (d['regular_price'] ?? '').toString();
            final saleTo = (d['sale_to'] as num?)?.toInt();

            return ListView(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 110),
              children: [
                if (salePrice.isNotEmpty && regularPrice.isNotEmpty) ...[
                  AmazingOfferBar(saleTo: saleTo),
                  const SizedBox(height: 10),
                ],
                if (cats.isNotEmpty) ...[
                  Builder(builder: (context) {
                    final mapped = cats.map((e) => Map<String, dynamic>.from(e)).toList();
                    mapped.sort((a, b) => List<dynamic>.from(b['path'] ?? []).length.compareTo(List<dynamic>.from(a['path'] ?? []).length));
                    final path = List<dynamic>.from(mapped.first['path'] ?? [mapped.first]);
                    return SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      reverse: true,
                      child: Row(
                        children: [
                          TextButton(
                            style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 5), minimumSize: const Size(0, 30)),
                            onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
                            child: const Text('خانه', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                          ),
                          const Icon(Icons.chevron_left_rounded, size: 14, color: Colors.black38),
                          ...List.generate(path.length, (i) {
                          final c = Map<String, dynamic>.from(path[i]);
                          final name = (c['name'] ?? '').toString();
                          final slug = (c['slug'] ?? '').toString();
                          return Row(children: [
                            TextButton(
                              onPressed: slug.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryProductsScreen(name: name, slug: slug))),
                              style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 5), minimumSize: const Size(0, 30)),
                              child: Text(name, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                            ),
                            if (i < path.length - 1) const Icon(Icons.chevron_left_rounded, size: 17, color: Colors.black38),
                          ]);
                        }),
                        ],
                      ),
                    );
                  }),
                  const SizedBox(height: 6),
                ],
                if (gallery.isNotEmpty) ...[
                  AspectRatio(
                      aspectRatio: 1,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: const Color(0xFFEAE6E8)),
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: PageView.builder(
                          controller: galleryController,
                          itemCount: gallery.length,
                          onPageChanged: (v) => setState(() => imageIndex = v),
                          itemBuilder: (_, i) => InkWell(
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => GalleryScreen(images: gallery, initial: i)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: CachedNetworkImage(imageUrl: gallery[i], fit: BoxFit.contain),
                            ),
                          ),
                        ),
                      ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 82,
                    child: ListView.separated(
                      reverse: true,
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      itemCount: gallery.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (_, i) => InkWell(
                        borderRadius: BorderRadius.circular(14),
                        onTap: () {
                          setState(() => imageIndex = i);
                          galleryController.animateToPage(
                            i,
                            duration: const Duration(milliseconds: 280),
                            curve: Curves.easeOutCubic,
                          );
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          width: 78,
                          height: 78,
                          padding: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: i == imageIndex ? LiyonaTheme.pink : const Color(0xFFE5E2E4),
                              width: i == imageIndex ? 2.2 : 1,
                            ),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: CachedNetworkImage(imageUrl: gallery[i], fit: BoxFit.cover),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Container(
                      margin: const EdgeInsets.only(top: 7),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(color: const Color(0xFFF4F1F2), borderRadius: BorderRadius.circular(12)),
                      child: Text('${imageIndex + 1} / ${gallery.length}'),
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        (d['name'] ?? widget.product.name).toString(),
                        textAlign: TextAlign.right,
                        textDirection: TextDirection.rtl,
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, height: 1.5),
                      ),
                    ),
                    IconButton(onPressed: () {}, icon: const Icon(Icons.favorite_border_rounded)),
                    IconButton(onPressed: () {}, icon: const Icon(Icons.ios_share_rounded)),
                  ],
                ),
                if ((d['average_rating'] ?? '0').toString() != '0')
                  Row(
                    children: [
                      const Icon(Icons.star_rounded, color: Colors.amber, size: 20),
                      Text(' ${d['average_rating']}  '),
                      Text('${d['review_count'] ?? 0} نظر', style: const TextStyle(color: Colors.black54)),
                    ],
                  ),
                const SizedBox(height: 8),
                Text(
                  money(shownPrice),
                  style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: LiyonaTheme.pink),
                ),
                if (variation != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Text(
                      variation['in_stock'] == false ? 'ناموجود' : ((variation['stock_quantity'] ?? '').toString().isNotEmpty ? '${variation['stock_quantity']} عدد موجود در انبار' : 'موجود و آماده ارسال'),
                      style: TextStyle(
                        color: variation['in_stock'] == false ? Colors.red : Colors.green.shade700,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                if (short.isNotEmpty) ...[
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: const Color(0xFFFAF8F9), borderRadius: BorderRadius.circular(18)),
                    child: HtmlContent(html: short),
                  ),
                ],
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: const Color(0xFFFFF3F7), borderRadius: BorderRadius.circular(18)),
                  child: const Row(
                    children: [
                      Icon(Icons.verified_outlined, color: LiyonaTheme.pink),
                      SizedBox(width: 8),
                      Expanded(child: Text('ضمانت اصالت کالا  •  ارسال سریع  •  خرید امن', style: TextStyle(fontWeight: FontWeight.w700))),
                    ],
                  ),
                ),
                if (attrs.isNotEmpty) ...[
                  const SizedBox(height: 22),
                  const Text('انتخاب ویژگی‌ها', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  ...attrs.map((a) {
                    final slug = attrSlug(a);
                    final options = attrOptions(a);
                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: const Color(0xFFE8E3E6)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text((a['name'] ?? '').toString(), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: options.map((o) {
                              final value = o['value'] ?? '';
                              final isSelected = selected[slug] == value;
                              final available = optionAvailable(d, slug, value);
                              return ChoiceChip(
                                avatar: available ? null : const Icon(Icons.close_rounded, size: 16, color: Colors.black38),
                                label: Text(o['label'] ?? ''),
                                selected: isSelected,
                                showCheckmark: false,
                                selectedColor: const Color(0xFFFFDDE9),
                                disabledColor: const Color(0xFFF1EFF0),
                                side: BorderSide(color: isSelected ? LiyonaTheme.pink : const Color(0xFFD8D3D6)),
                                labelStyle: TextStyle(
                                  decoration: available ? null : TextDecoration.lineThrough,
                                  color: !available ? Colors.black38 : (isSelected ? LiyonaTheme.pink : const Color(0xFF332F31)),
                                  fontWeight: isSelected ? FontWeight.w900 : FontWeight.w700,
                                ),
                                onSelected: available ? (_) => setState(() => selected[slug] = value) : null,
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                    );
                  }),
                ],
                Container(
                  margin: const EdgeInsets.only(top: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(color: const Color(0xFFFAF8F9), borderRadius: BorderRadius.circular(18)),
                  child: Row(
                    children: [
                      const Text('تعداد', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                      const Spacer(),
                      IconButton(onPressed: qty > 1 ? () => setState(() => qty--) : null, icon: const Icon(Icons.remove_circle_outline_rounded)),
                      Text('$qty', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                      IconButton(onPressed: () => setState(() => qty++), icon: const Icon(Icons.add_circle_outline_rounded)),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                ExpansionSection(
                  title: 'توضیحات محصول',
                  child: desc.isEmpty ? const Text('توضیحی ثبت نشده') : HtmlContent(html: desc),
                ),
                ExpansionSection(
                  title: 'مشخصات و اطلاعات',
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (cats.isNotEmpty)
                        MetaRow(title: 'دسته‌بندی', items: cats.map((e) => Map<String, dynamic>.from(e)['name'].toString()).toList()),
                      if (tags.isNotEmpty)
                        MetaRow(title: 'برچسب‌ها', items: tags.map((e) => Map<String, dynamic>.from(e)['name'].toString()).toList()),
                      if ((d['sku'] ?? '').toString().isNotEmpty) Text('کد محصول: ${d['sku']}'),
                    ],
                  ),
                ),
                ExpansionSection(title: 'نظرات کاربران', child: ReviewsList(productId: widget.product.id)),
                if (cats.isNotEmpty) ...[
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      const Expanded(child: Text('محصولات مشابه', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
                      TextButton(
                        onPressed: () {
                          final c = Map<String, dynamic>.from(cats.last);
                          Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryProductsScreen(name: (c['name'] ?? '').toString(), slug: (c['slug'] ?? '').toString())));
                        },
                        child: const Text('مشاهده همه'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  FutureBuilder<List<Product>>(
                    future: api.products(category: (Map<String, dynamic>.from(cats.last)['slug'] ?? '').toString(), perPage: 8),
                    builder: (context, rs) {
                      final related = (rs.data ?? <Product>[]).where((p) => p.id != widget.product.id).take(6).toList();
                      if (rs.connectionState != ConnectionState.done) return const SizedBox(height: 120, child: LiyonaLoader());
                      if (related.isEmpty) return const SizedBox.shrink();
                      return SizedBox(
                        height: 150,
                        child: ListView.separated(
                          reverse: true,
                          scrollDirection: Axis.horizontal,
                          itemCount: related.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 8),
                          itemBuilder: (_, i) => InkWell(
                            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailScreen(product: related[i]))),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(16),
                              child: SizedBox(width: 150, child: CachedNetworkImage(imageUrl: related[i].image, fit: BoxFit.cover)),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ],
            );
          },
        ),
        bottomNavigationBar: SafeArea(
          child: Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
            child: FutureBuilder<Map<String, dynamic>>(
              future: detail,
              builder: (context, s) {
                final d=s.data; final variable=d!=null && (d['type']??'')=='variable'; final v=d==null?null:matchedVariation(d); final price=(v?['price']??d?['price']??widget.product.price).toString();
                return SizedBox(height:60,child:Row(children:[
                  Expanded(child:Text(money(price),style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:LiyonaTheme.pink))),
                  const SizedBox(width:10),
                  Expanded(flex:2,child:FilledButton.icon(onPressed:adding||d==null?null:()=>variable?showVariantSheet(d):add(d),icon:Icon(variable?Icons.tune_rounded:Icons.shopping_bag_outlined),label:Text(adding?'در حال افزودن...':variable?'انتخاب گزینه‌ها':'افزودن به سبد خرید'))),
                ]));
              },
            ),
          ),
        ),
      ),
    );
  }
}

class AmazingOfferBar extends StatelessWidget {
  final int? saleTo;
  const AmazingOfferBar({super.key,this.saleTo});
  @override Widget build(BuildContext context){
    String remain='تخفیف ویژه';
    if(saleTo!=null){final d=DateTime.fromMillisecondsSinceEpoch(saleTo!*1000).difference(DateTime.now());if(!d.isNegative){final h=d.inHours;final m=d.inMinutes.remainder(60);remain='$h:${m.toString().padLeft(2,'0')} تا پایان';}}
    return Container(padding:const EdgeInsets.symmetric(horizontal:14,vertical:12),decoration:BoxDecoration(color:const Color(0xFFFFE8EE),border:Border.all(color:LiyonaTheme.pink,width:1.5),borderRadius:BorderRadius.circular(16)),child:Row(children:[const Icon(Icons.local_fire_department_rounded,color:LiyonaTheme.pink),const SizedBox(width:7),const Expanded(child:Text('پیشنهاد شگفت‌انگیز',style:TextStyle(color:LiyonaTheme.pink,fontWeight:FontWeight.w900))),Text(remain,style:const TextStyle(color:LiyonaTheme.pink,fontWeight:FontWeight.w800))]));
  }
}

class GalleryScreen extends StatefulWidget {
  final List<String> images;
  final int initial;
  const GalleryScreen({super.key, required this.images, required this.initial});
  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  late PageController controller;
  late int index;
  @override
  void initState() {
    super.initState();
    index = widget.initial;
    controller = PageController(initialPage: index);
  }
  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
            foregroundColor: Colors.white,
            title: Text('${index + 1} / ${widget.images.length}'),
          ),
          body: PageView.builder(
            controller: controller,
            onPageChanged: (v) => setState(() => index = v),
            itemCount: widget.images.length,
            itemBuilder: (_, i) => InteractiveViewer(
              minScale: 1,
              maxScale: 5,
              child: Center(child: CachedNetworkImage(imageUrl: widget.images[i], fit: BoxFit.contain)),
            ),
          ),
        ),
      );
}

class ExpansionSection extends StatelessWidget {
  final String title;
  final Widget child;
  const ExpansionSection({super.key, required this.title, required this.child});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE8E3E6)),
        ),
        child: ExpansionTile(
          shape: const Border(),
          collapsedShape: const Border(),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
          children: [Padding(padding: const EdgeInsets.fromLTRB(14, 0, 14, 14), child: child)],
        ),
      );
}

class MetaRow extends StatelessWidget {
  final String title;
  final List<String> items;
  const MetaRow({super.key, required this.title, required this.items});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('$title:', style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 7),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: items.map((e) => Chip(label: Text(e), visualDensity: VisualDensity.compact)).toList(),
            ),
          ],
        ),
      );
}

class ReviewsList extends StatelessWidget {
  final int productId;
  const ReviewsList({super.key, required this.productId});
  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
        future: api.productReviews(productId),
        builder: (context, s) {
          if (s.connectionState != ConnectionState.done) return const Padding(padding: EdgeInsets.all(16), child: LiyonaLoader(size: 52));
          final items = s.data ?? [];
          if (items.isEmpty) return const Padding(padding: EdgeInsets.all(12), child: Text('هنوز نظری ثبت نشده', textAlign: TextAlign.right));
          final ratings = items.map((e) => (Map<String,dynamic>.from(e)['rating'] as num?)?.toInt() ?? 0).where((e)=>e>0).toList();
          final avg = ratings.isEmpty ? 0.0 : ratings.reduce((a,b)=>a+b) / ratings.length;
          return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(children:[
              Text(avg.toStringAsFixed(1), style: const TextStyle(fontSize:28,fontWeight:FontWeight.w900)),
              const SizedBox(width:6), const Icon(Icons.star_rounded,color:Colors.amber),
              const Spacer(), Text('${items.length} دیدگاه',style:const TextStyle(color:Colors.black54,fontWeight:FontWeight.w700)),
            ]),
            const SizedBox(height:10),
            ...List.generate(5,(i){ final star=5-i; final n=ratings.where((x)=>x==star).length; final v=ratings.isEmpty?0.0:n/ratings.length; return Padding(padding:const EdgeInsets.symmetric(vertical:2),child:Row(children:[SizedBox(width:30,child:Text('$star ⭐',style:const TextStyle(fontSize:11))),const SizedBox(width:6),Expanded(child:LinearProgressIndicator(value:v,minHeight:6,borderRadius:BorderRadius.circular(9))),const SizedBox(width:8),SizedBox(width:22,child:Text('$n',style:const TextStyle(fontSize:11))) ]));}),
            const SizedBox(height:12),
            SizedBox(height:205,child:ListView.separated(reverse:true,scrollDirection:Axis.horizontal,itemCount:items.length.clamp(0,10),separatorBuilder:(_,__)=>const SizedBox(width:8),itemBuilder:(_,i){
              final r=Map<String,dynamic>.from(items[i]); final rating=(r['rating'] as num?)?.toInt()??0;
              return Container(width:280,padding:const EdgeInsets.all(14),decoration:BoxDecoration(border:Border.all(color:const Color(0xFFE8E3E6)),borderRadius:BorderRadius.circular(16)),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
                Row(children:[CircleAvatar(radius:18,child:Text(((r['author']??'ک').toString()).characters.first)),const SizedBox(width:8),Expanded(child:Text((r['author']??'کاربر').toString(),style:const TextStyle(fontWeight:FontWeight.w900))),if(r['verified']==true) Container(padding:const EdgeInsets.symmetric(horizontal:7,vertical:3),decoration:BoxDecoration(color:const Color(0xFFE9F8ED),borderRadius:BorderRadius.circular(10)),child:const Text('خریدار',style:TextStyle(fontSize:10,color:Colors.green))) ]),
                const SizedBox(height:8),Row(children:List.generate(5,(x)=>Icon(x<rating?Icons.star_rounded:Icons.star_border_rounded,size:17,color:Colors.amber))),
                const SizedBox(height:8),Expanded(child:Text((r['review']??'').toString(),textAlign:TextAlign.right,maxLines:5,overflow:TextOverflow.ellipsis)),
                Row(children:[Text((r['date']??'').toString(),style:const TextStyle(fontSize:11,color:Colors.black45)),const Spacer(),const Icon(Icons.thumb_up_alt_outlined,size:16,color:Colors.black45),const SizedBox(width:4),Text('${r['helpful']??0}',style:const TextStyle(fontSize:11))]),
              ]));
            })),
          ]);
        },
      );
}

class ProductSearchPage extends StatefulWidget {
  const ProductSearchPage({super.key});
  @override State<ProductSearchPage> createState()=>_ProductSearchPageState();
}
class _ProductSearchPageState extends State<ProductSearchPage> {
  final c=TextEditingController(); Future<List<Product>>? f;
  void run(String q){ final v=q.trim(); if(v.length<2){setState(()=>f=null);return;} setState(()=>f=api.products(search:v,perPage:30)); }
  @override void dispose(){c.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:TextField(controller:c,autofocus:true,textDirection:TextDirection.rtl,onChanged:run,decoration:const InputDecoration(hintText:'جستجو بین محصولات لیونا...',border:InputBorder.none,prefixIcon:Icon(Icons.search_rounded)))),body:f==null?const Center(child:Text('نام محصول را جستجو کنید')):FutureBuilder<List<Product>>(future:f,builder:(context,s){if(s.connectionState!=ConnectionState.done)return const LiyonaLoader();final items=s.data??[];if(items.isEmpty)return const Center(child:Text('محصولی پیدا نشد'));return ListView.separated(padding:const EdgeInsets.all(12),itemCount:items.length,separatorBuilder:(_,__)=>const Divider(),itemBuilder:(_,i){final p=items[i];return ListTile(leading:ClipRRect(borderRadius:BorderRadius.circular(10),child:CachedNetworkImage(imageUrl:p.image,width:62,height:62,fit:BoxFit.cover)),title:Text(p.name,textAlign:TextAlign.right),subtitle:Text(money(p.price),textAlign:TextAlign.right,style:const TextStyle(color:LiyonaTheme.pink,fontWeight:FontWeight.w900)),onTap:()=>Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>ProductDetailScreen(product:p))));});})));
}
