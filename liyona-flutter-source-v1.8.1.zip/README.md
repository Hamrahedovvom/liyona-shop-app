# Liyona Shop v1.8.1

This maintenance release fixes the Android build bootstrap used by CI.
The Android host project is recreated with the installed Flutter SDK before building,
avoiding the unsupported Gradle project error.

Build:
    bash build_android.sh
