class AppConfig {
  static const siteUrl = 'https://liyona.ir';
  static const customApi = '$siteUrl/wp-json/liyona-app/v1';
  static const storeApi = '$siteUrl/wp-json/wc/store/v1';
}
