class Product {
  final int id;
  final String name;
  final String image;
  final String priceHtml;
  final String regular;
  final String sale;

  Product({required this.id, required this.name, required this.image, required this.priceHtml, required this.regular, required this.sale});

  factory Product.fromJson(Map<String,dynamic> j) {
    final images = (j['images'] as List? ?? []);
    final prices = (j['prices'] as Map<String,dynamic>? ?? {});
    return Product(
      id: j['id'] ?? 0,
      name: j['name'] ?? '',
      image: images.isNotEmpty ? (images.first['src'] ?? '') : '',
      priceHtml: j['price_html'] ?? '',
      regular: prices['regular_price']?.toString() ?? '',
      sale: prices['sale_price']?.toString() ?? '',
    );
  }
}
