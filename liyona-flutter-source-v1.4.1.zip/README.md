# Liyona Shop Android App

Package: `com.liyona.shop`
Backend: `https://liyona.ir`

## Build APK
1. Install Flutter stable + Android SDK.
2. Run `flutter create . --platforms=android --org com.liyona` once if the Android folder is missing.
3. Run `flutter pub get`.
4. Run `dart run flutter_launcher_icons`.
5. Run `dart run flutter_native_splash:create`.
6. Build: `flutter build apk --release`.

The APK will be created at `build/app/outputs/flutter-apk/app-release.apk`.

## GitHub Actions
The included workflow can build an APK automatically on GitHub and expose it as an Actions artifact.
