import 'package:flutter/material.dart';
import '../services/api.dart';

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('سفارش‌های من')),
          body: FutureBuilder<List<dynamic>>(
            future: api.myOrders(),
            builder: (c, s) {
              if (s.connectionState != ConnectionState.done) {
                return const Center(child: CircularProgressIndicator());
              }
              if (s.hasError) {
                return const Center(child: Text('ابتدا وارد حساب کاربری شوید'));
              }

              final a = s.data ?? [];
              if (a.isEmpty) {
                return const Center(child: Text('هنوز سفارشی ندارید'));
              }

              return ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: a.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (_, i) {
                  final o = a[i];
                  return Card(
                    child: ListTile(
                      title: Text('سفارش #${o['number'] ?? o['id']}'),
                      subtitle: Text(o['status_label'] ?? o['status'] ?? ''),
                      trailing: Text('${o['total']} ${o['currency']}'),
                    ),
                  );
                },
              );
            },
          ),
        ),
      );
}
