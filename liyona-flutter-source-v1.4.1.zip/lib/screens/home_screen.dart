import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';

import '../services/api.dart';
import '../models/product.dart';
import '../widgets/product_card.dart';
import '../core/theme.dart';
import 'category_products_screen.dart';

class HomeScreen extends StatefulWidget {
  final ValueChanged<int> onSelectTab;
  const HomeScreen({super.key, required this.onSelectTab});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<dynamic>> categories;
  final search = TextEditingController();

  @override
  void initState() {
    super.initState();
    categories = api.categories();
  }

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: () async {
          setState(() => categories = api.categories());
          await categories;
        },
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () => widget.onSelectTab(4),
                          icon: const Icon(Icons.person_outline),
                        ),
                        const Spacer(),
                        Image.asset('assets/images/liyona_logo.jpg', height: 52),
                        const Spacer(),
                        IconButton(
                          onPressed: () => widget.onSelectTab(2),
                          icon: const Icon(Icons.shopping_bag_outlined),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: search,
                      onSubmitted: (q) {
                        if (q.trim().isEmpty) return;
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => _AllProductsScreen(
                              title: 'نتایج جستجو',
                              future: api.products(search: q, perPage: 50),
                            ),
                          ),
                        );
                      },
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        hintText: 'جستجو بین محصولات لیونا...',
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(26),
                        gradient: const LinearGradient(
                          colors: [
                            Color(0xFFFFDCEB),
                            Color(0xFFF4E7FF),
                            Color(0xFFE7F2FF),
                          ],
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                        ),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'استایل جدیدت از اینجا شروع میشه',
                                  style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.w900,
                                    color: LiyonaTheme.pink,
                                    height: 1.5,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                const Text('جدیدترین انتخاب‌ها، تخفیف‌ها و ترندها'),
                                const SizedBox(height: 14),
                                FilledButton(
                                  onPressed: () => widget.onSelectTab(1),
                                  child: const Text('مشاهده دسته‌بندی‌ها'),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          Container(
                            width: 82,
                            height: 118,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(.65),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: const Icon(
                              Icons.auto_awesome,
                              size: 48,
                              color: LiyonaTheme.pink,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Row(
                      children: [
                        Expanded(
                          child: _Feature(
                            icon: Icons.verified_outlined,
                            text: 'ضمانت اصالت',
                          ),
                        ),
                        SizedBox(width: 8),
                        Expanded(
                          child: _Feature(
                            icon: Icons.local_shipping_outlined,
                            text: 'ارسال سریع',
                          ),
                        ),
                        SizedBox(width: 8),
                        Expanded(
                          child: _Feature(
                            icon: Icons.lock_outline,
                            text: 'خرید امن',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: FutureBuilder<List<dynamic>>(
                future: categories,
                builder: (context, s) {
                  final items = s.data ?? [];
                  if (items.isEmpty) return const SizedBox.shrink();
                  return _CategoriesStrip(
                    items: items,
                    onAll: () => widget.onSelectTab(1),
                  );
                },
              ),
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 8)),
            SliverToBoxAdapter(
              child: _ProductSection(
                title: 'جدیدترین محصولات',
                future: api.products(perPage: 12),
                onAll: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => _AllProductsScreen(
                      title: 'جدیدترین محصولات',
                      future: api.products(perPage: 50),
                    ),
                  ),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: _SaleSection(
                future: api.products(perPage: 16, onSale: true),
                onAll: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => _AllProductsScreen(
                      title: 'تخفیف‌خورده‌ها',
                      future: api.products(perPage: 50, onSale: true),
                    ),
                  ),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: FutureBuilder<List<dynamic>>(
                future: categories,
                builder: (context, s) {
                  final items = s.data ?? [];
                  return Column(
                    children: items.map((raw) {
                      final c = Map<String, dynamic>.from(raw);
                      final name = (c['name'] ?? '').toString();
                      final slug = (c['slug'] ?? '').toString();
                      return _ProductSection(
                        title: name,
                        future: api.products(category: slug, perPage: 8),
                        onAll: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CategoryProductsScreen(
                              name: name,
                              slug: slug,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 24)),
          ],
        ),
      ),
    );
  }
}

class _CategoriesStrip extends StatelessWidget {
  final List<dynamic> items;
  final VoidCallback onAll;
  const _CategoriesStrip({required this.items, required this.onAll});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Text(
                  'دسته‌بندی‌ها',
                  style: Theme.of(context)
                      .textTheme
                      .titleLarge
                      ?.copyWith(fontWeight: FontWeight.w900),
                ),
                const Spacer(),
                TextButton(onPressed: onAll, child: const Text('مشاهده همه')),
              ],
            ),
          ),
          SizedBox(
            height: 112,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (context, i) {
                final c = Map<String, dynamic>.from(items[i]);
                final image = (c['image'] ?? '').toString();
                return InkWell(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => CategoryProductsScreen(
                        name: (c['name'] ?? '').toString(),
                        slug: (c['slug'] ?? '').toString(),
                      ),
                    ),
                  ),
                  child: SizedBox(
                    width: 82,
                    child: Column(
                      children: [
                        CircleAvatar(
                          radius: 34,
                          backgroundColor: const Color(0xFFFFEDF4),
                          backgroundImage: image.isNotEmpty
                              ? CachedNetworkImageProvider(image)
                              : null,
                          child: image.isEmpty
                              ? const Icon(Icons.category_outlined)
                              : null,
                        ),
                        const SizedBox(height: 7),
                        Text(
                          (c['name'] ?? '').toString(),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _ProductSection extends StatelessWidget {
  final String title;
  final Future<List<Product>> future;
  final VoidCallback onAll;
  const _ProductSection({
    required this.title,
    required this.future,
    required this.onAll,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 18),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.w900),
                  ),
                ),
                TextButton(onPressed: onAll, child: const Text('مشاهده همه')),
              ],
            ),
          ),
          SizedBox(
            height: 330,
            child: FutureBuilder<List<Product>>(
              future: future,
              builder: (context, s) {
                if (s.connectionState != ConnectionState.done) {
                  return const Center(child: CircularProgressIndicator());
                }
                final items = s.data ?? [];
                if (items.isEmpty) {
                  return const Center(child: Text('محصولی برای نمایش نیست'));
                }
                return ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (_, i) => SizedBox(
                    width: 185,
                    child: ProductCard(p: items[i]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _SaleSection extends StatelessWidget {
  final Future<List<Product>> future;
  final VoidCallback onAll;
  const _SaleSection({required this.future, required this.onAll});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 20),
      padding: const EdgeInsets.symmetric(vertical: 18),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFFE50064), Color(0xFFFF3F7F)],
        ),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Icon(Icons.local_fire_department, color: Colors.white),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text(
                    'پیشنهادهای شگفت‌انگیز',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: onAll,
                  child: const Text(
                    'مشاهده همه',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 330,
            child: FutureBuilder<List<Product>>(
              future: future,
              builder: (context, s) {
                if (s.connectionState != ConnectionState.done) {
                  return const Center(
                    child: CircularProgressIndicator(color: Colors.white),
                  );
                }
                final items = s.data ?? [];
                if (items.isEmpty) {
                  return const Center(
                    child: Text(
                      'محصول تخفیف‌خورده‌ای نیست',
                      style: TextStyle(color: Colors.white),
                    ),
                  );
                }
                return ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (_, i) => SizedBox(
                    width: 185,
                    child: ProductCard(p: items[i]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _AllProductsScreen extends StatelessWidget {
  final String title;
  final Future<List<Product>> future;
  const _AllProductsScreen({required this.title, required this.future});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(title)),
        body: FutureBuilder<List<Product>>(
          future: future,
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (s.hasError) {
              return const Center(child: Text('دریافت محصولات ناموفق بود'));
            }
            final items = s.data ?? [];
            return GridView.builder(
              padding: const EdgeInsets.all(14),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: .62,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemCount: items.length,
              itemBuilder: (_, i) => ProductCard(p: items[i]),
            );
          },
        ),
      ),
    );
  }
}

class _Feature extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Feature({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFF1E8EC)),
      ),
      child: Column(
        children: [
          Icon(icon, color: LiyonaTheme.pink, size: 22),
          const SizedBox(height: 5),
          Text(
            text,
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}
