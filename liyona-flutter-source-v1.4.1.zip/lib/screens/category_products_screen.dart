import 'package:flutter/material.dart';
import '../services/api.dart';
import '../models/product.dart';
import '../widgets/product_card.dart';

class CategoryProductsScreen extends StatefulWidget {
  final String name;
  final String slug;
  const CategoryProductsScreen({super.key, required this.name, required this.slug});
  @override State<CategoryProductsScreen> createState() => _CategoryProductsScreenState();
}

class _CategoryProductsScreenState extends State<CategoryProductsScreen> {
  late Future<List<Product>> future;
  @override void initState(){super.initState();future=api.products(category: widget.slug, perPage: 50);}
  @override Widget build(BuildContext context)=>Directionality(textDirection: TextDirection.rtl,child:Scaffold(
    appBar: AppBar(title: Text(widget.name)),
    body: FutureBuilder<List<Product>>(future: future,builder:(context,s){
      if(s.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());
      if(s.hasError)return const Center(child:Text('دریافت محصولات این دسته ناموفق بود'));
      final items=s.data??[];
      if(items.isEmpty)return const Center(child:Text('محصولی در این دسته پیدا نشد'));
      return GridView.builder(padding: const EdgeInsets.all(14),gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,childAspectRatio:.62,crossAxisSpacing:10,mainAxisSpacing:10),itemCount:items.length,itemBuilder:(_,i)=>ProductCard(p:items[i]));
    }),
  ));
}
