import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';

import '../models/product.dart';
import '../services/api.dart';
import '../core/theme.dart';
import '../utils/format.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;
  const ProductDetailScreen({super.key, required this.product});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  late Future<Map<String, dynamic>> detail;
  int qty = 1;
  bool adding = false;
  int galleryIndex = 0;
  final Map<String, String> selected = {};

  @override
  void initState() {
    super.initState();
    detail = api.product(widget.product.id);
  }

  Future<void> add(Map<String, dynamic> d) async {
    final vars = List<dynamic>.from(d['variations'] ?? []);
    int id = widget.product.id;
    List<Map<String, String>> variation = [];

    if (vars.isNotEmpty) {
      Map<String, dynamic>? match;

      for (final raw in vars) {
        final v = Map<String, dynamic>.from(raw);
        final attrs = List<dynamic>.from(v['attributes'] ?? []);
        bool ok = true;

        for (final a0 in attrs) {
          final a = Map<String, dynamic>.from(a0);
          final key = (a['name'] ?? '').toString();
          final val = (a['option'] ?? '').toString();
          if (val.isNotEmpty && selected[key] != val) {
            ok = false;
            break;
          }
        }

        if (ok) {
          match = v;
          break;
        }
      }

      if (match == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('لطفاً گزینه‌های محصول را انتخاب کنید')),
        );
        return;
      }

      id = (match['id'] as num?)?.toInt() ?? id;
      variation = List<dynamic>.from(match['attributes'] ?? []).map((e) {
        final a = Map<String, dynamic>.from(e);
        return {
          'attribute': (a['name'] ?? '').toString(),
          'value': (a['option'] ?? '').toString(),
        };
      }).toList();
    }

    setState(() => adding = true);
    try {
      await api.addToCart(id, quantity: qty, variation: variation);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('محصول به سبد خرید اضافه شد')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'افزودن به سبد خرید ناموفق بود: ${e.toString().split('\n').first}',
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => adding = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('جزئیات محصول')),
        body: FutureBuilder<Map<String, dynamic>>(
          future: detail,
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (s.hasError) {
              return const Center(child: Text('دریافت جزئیات محصول ناموفق بود'));
            }

            final d = s.data ?? {};
            final gallery = <String>[];
            final main = (d['image'] ?? widget.product.image).toString();
            if (main.isNotEmpty) gallery.add(main);
            for (final g in List<dynamic>.from(d['gallery'] ?? [])) {
              final u = g.toString();
              if (u.isNotEmpty && !gallery.contains(u)) gallery.add(u);
            }

            final attrs = List<dynamic>.from(d['attributes'] ?? []);
            final cats = List<dynamic>.from(d['categories'] ?? []);
            final tags = List<dynamic>.from(d['tags'] ?? []);
            final desc = (d['description'] ?? '').toString();
            final short = (d['short_description'] ?? '').toString();
            final price = (d['sale_price'] ?? '').toString().isNotEmpty
                ? d['sale_price']
                : (d['price'] ?? widget.product.price);

            return ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
              children: [
                if (gallery.isNotEmpty) ...[
                  SizedBox(
                    height: 390,
                    child: PageView.builder(
                      itemCount: gallery.length,
                      onPageChanged: (i) => setState(() => galleryIndex = i),
                      itemBuilder: (_, i) => ClipRRect(
                        borderRadius: BorderRadius.circular(24),
                        child: CachedNetworkImage(
                          imageUrl: gallery[i],
                          fit: BoxFit.cover,
                          errorWidget: (_, __, ___) =>
                              const Icon(Icons.image_not_supported_outlined),
                        ),
                      ),
                    ),
                  ),
                  if (gallery.length > 1)
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: SizedBox(
                        height: 74,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: gallery.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 8),
                          itemBuilder: (_, i) => GestureDetector(
                            onTap: () => setState(() => galleryIndex = i),
                            child: Container(
                              width: 68,
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: i == galleryIndex
                                      ? LiyonaTheme.pink
                                      : Colors.transparent,
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: CachedNetworkImage(
                                  imageUrl: gallery[i],
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
                const SizedBox(height: 18),
                Text(
                  (d['name'] ?? widget.product.name).toString(),
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.w900, height: 1.5),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Text(
                      money(price),
                      textDirection: TextDirection.ltr,
                      style: const TextStyle(
                        color: LiyonaTheme.pink,
                        fontSize: 21,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const Spacer(),
                    if ((d['average_rating'] ?? '0').toString() != '0')
                      Row(
                        children: [
                          const Icon(Icons.star, color: Colors.amber, size: 20),
                          Text(
                            '${d['average_rating']} (${d['rating_count'] ?? 0})',
                          ),
                        ],
                      ),
                  ],
                ),
                if (short.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Text(short, style: const TextStyle(height: 1.9)),
                ],
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF6F9),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.verified_outlined, color: LiyonaTheme.pink),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text('ضمانت اصالت کالا • ارسال سریع • خرید امن'),
                      ),
                    ],
                  ),
                ),
                if (attrs.isNotEmpty) ...[
                  const SizedBox(height: 22),
                  Text(
                    'انتخاب ویژگی‌ها',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 10),
                  ...attrs.map((raw) {
                    final a = Map<String, dynamic>.from(raw);
                    final name = (a['name'] ?? '').toString();
                    final options = List<dynamic>.from(a['options'] ?? [])
                        .map((e) => e.toString())
                        .where((e) => e.isNotEmpty)
                        .toList();
                    if (options.isEmpty) return const SizedBox.shrink();

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            name,
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: options
                                .map(
                                  (o) => ChoiceChip(
                                    label: Text(o),
                                    selected: selected[name] == o,
                                    onSelected: (_) =>
                                        setState(() => selected[name] = o),
                                  ),
                                )
                                .toList(),
                          ),
                        ],
                      ),
                    );
                  }),
                ],
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Text(
                      'تعداد',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: qty > 1 ? () => setState(() => qty--) : null,
                      icon: const Icon(Icons.remove_circle_outline),
                    ),
                    Text(
                      '$qty',
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                      ),
                    ),
                    IconButton(
                      onPressed: () => setState(() => qty++),
                      icon: const Icon(Icons.add_circle_outline),
                    ),
                  ],
                ),
                if (desc.isNotEmpty) ...[
                  const SizedBox(height: 20),
                  Text(
                    'توضیحات محصول',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 10),
                  Text(desc, style: const TextStyle(height: 2)),
                ],
                if (cats.isNotEmpty) ...[
                  const SizedBox(height: 20),
                  _Meta(
                    title: 'دسته‌بندی',
                    items: cats
                        .map((e) => Map<String, dynamic>.from(e)['name'].toString())
                        .toList(),
                  ),
                ],
                if (tags.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  _Meta(
                    title: 'برچسب‌ها',
                    items: tags
                        .map((e) => Map<String, dynamic>.from(e)['name'].toString())
                        .toList(),
                  ),
                ],
                if ((d['sku'] ?? '').toString().isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Text(
                    'کد محصول: ${d['sku']}',
                    style: const TextStyle(color: Colors.black54),
                  ),
                ],
                const SizedBox(height: 20),
                _Reviews(productId: widget.product.id),
              ],
            );
          },
        ),
        bottomSheet: SafeArea(
          child: Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
            child: FutureBuilder<Map<String, dynamic>>(
              future: detail,
              builder: (context, s) => SizedBox(
                width: double.infinity,
                height: 54,
                child: FilledButton.icon(
                  onPressed: adding || !s.hasData ? null : () => add(s.data!),
                  icon: const Icon(Icons.shopping_bag_outlined),
                  label: Text(
                    adding ? 'در حال افزودن...' : 'افزودن به سبد خرید',
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Meta extends StatelessWidget {
  final String title;
  final List<String> items;
  const _Meta({required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$title: ', style: const TextStyle(fontWeight: FontWeight.w800)),
        Expanded(
          child: Wrap(
            spacing: 6,
            runSpacing: 6,
            children: items.map((e) => Chip(label: Text(e))).toList(),
          ),
        ),
      ],
    );
  }
}

class _Reviews extends StatelessWidget {
  final int productId;
  const _Reviews({required this.productId});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<dynamic>>(
      future: api.productReviews(productId),
      builder: (context, s) {
        final items = s.data ?? [];
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  'نظرات کاربران',
                  style: Theme.of(context)
                      .textTheme
                      .titleLarge
                      ?.copyWith(fontWeight: FontWeight.w900),
                ),
                const Spacer(),
                Text('${items.length} نظر'),
              ],
            ),
            const SizedBox(height: 10),
            if (s.connectionState != ConnectionState.done)
              const Center(child: CircularProgressIndicator())
            else if (items.isEmpty)
              const Text(
                'هنوز نظری ثبت نشده',
                style: TextStyle(color: Colors.black54),
              )
            else
              ...items.take(5).map((raw) {
                final r = Map<String, dynamic>.from(raw);
                return Card(
                  child: ListTile(
                    title: Row(
                      children: [
                        Expanded(
                          child: Text(
                            (r['author'] ?? 'کاربر').toString(),
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                        const Icon(Icons.star, color: Colors.amber, size: 17),
                        Text((r['rating'] ?? '').toString()),
                      ],
                    ),
                    subtitle: Text((r['review'] ?? '').toString()),
                  ),
                );
              }),
          ],
        );
      },
    );
  }
}
