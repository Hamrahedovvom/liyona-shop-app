import 'package:flutter/material.dart';
import '../services/api.dart';
import '../core/theme.dart';

class LoginScreen extends StatefulWidget { const LoginScreen({super.key}); @override State<LoginScreen> createState()=>_LoginScreenState(); }
class _LoginScreenState extends State<LoginScreen>{
 final phone=TextEditingController(); final code=TextEditingController(); bool sent=false,busy=false; String? error;
 Future<void> submit() async { setState(()=>busy=true); try{ if(!sent){await api.requestOtp(phone.text.trim()); setState(()=>sent=true);} else {await api.verifyOtp(phone.text.trim(),code.text.trim()); if(mounted) Navigator.pop(context,true);} }catch(e){setState(()=>error='خطا در ارتباط با سرور یا اطلاعات واردشده');} finally{if(mounted)setState(()=>busy=false);} }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(),body:SafeArea(child:Padding(padding:const EdgeInsets.all(24),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
   const Icon(Icons.checkroom,size:82,color:LiyonaTheme.pink),
   const SizedBox(height:16),const Text('خوش آمدی به لیونا',textAlign:TextAlign.center,style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
   const SizedBox(height:8),const Text('ورود و عضویت با شماره موبایل',textAlign:TextAlign.center),
   const SizedBox(height:28),TextField(controller:phone,keyboardType:TextInputType.phone,textDirection:TextDirection.ltr,decoration:const InputDecoration(labelText:'شماره موبایل')),
   if(sent)...[const SizedBox(height:14),TextField(controller:code,keyboardType:TextInputType.number,textDirection:TextDirection.ltr,decoration:const InputDecoration(labelText:'کد تایید'))],
   if(error!=null)...[const SizedBox(height:12),Text(error!,style:const TextStyle(color:Colors.red),textAlign:TextAlign.center)],
   const SizedBox(height:18),FilledButton(onPressed:busy?null:submit,style:FilledButton.styleFrom(padding:const EdgeInsets.all(16)),child:Text(busy?'لطفاً صبر کنید...':sent?'تایید و ورود':'دریافت کد تایید')),
 ]))));
}
