import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../core/config.dart';
import '../models/product.dart';

class ApiService {
  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(seconds: 30),
    headers: {'Accept': 'application/json'},
  ));
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  String? cartToken;

  Future<Map<String, dynamic>> config() async {
    final r = await _dio.get('${AppConfig.customApi}/config');
    return Map<String, dynamic>.from(r.data);
  }

  Future<List<Product>> products({int page = 1, int perPage = 20, String? search, String? category, bool? onSale}) async {
    final r = await _dio.get('${AppConfig.customApi}/products', queryParameters: {
      'page': page,
      'per_page': perPage,
      if (search != null && search.isNotEmpty) 'search': search,
      if (category != null && category.isNotEmpty) 'category': category,
      if (onSale == true) 'on_sale': 1,
    });
    final data = Map<String, dynamic>.from(r.data);
    return List<dynamic>.from(data['items'] ?? [])
        .map((e) => Product.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<Map<String, dynamic>> product(int id) async {
    final r = await _dio.get('${AppConfig.customApi}/product/$id');
    final data = Map<String, dynamic>.from(r.data);
    return Map<String, dynamic>.from(data['product'] ?? {});
  }

  Future<List<dynamic>> productReviews(int id) async {
    final r = await _dio.get('${AppConfig.customApi}/product/$id/reviews');
    return List<dynamic>.from((r.data as Map<String, dynamic>)['items'] ?? []);
  }

  Future<void> submitReview(int productId, int rating, String review) async {
    await _dio.post('${AppConfig.customApi}/product/$productId/reviews',
        data: {'rating': rating, 'review': review}, options: await _authOptions());
  }

  Future<List<dynamic>> categories({int? parent}) async {
    final r = await _dio.get('${AppConfig.customApi}/categories', queryParameters: {if (parent != null) 'parent': parent});
    final data = Map<String, dynamic>.from(r.data);
    return List<dynamic>.from(data['items'] ?? []);
  }

  Future<void> requestOtp(String phone) async => _dio.post('${AppConfig.customApi}/request-otp', data: {'phone': phone});

  Future<void> verifyOtp(String phone, String code) async {
    final r = await _dio.post('${AppConfig.customApi}/verify-otp', data: {'phone': phone, 'code': code});
    await _storage.write(key: 'auth_token', value: r.data['token']);
  }

  Future<bool> isLoggedIn() async => (await _storage.read(key: 'auth_token'))?.isNotEmpty == true;
  Future<void> logout() => _storage.delete(key: 'auth_token');

  Future<Options> _authOptions() async {
    final t = await _storage.read(key: 'auth_token');
    return Options(headers: t == null ? {} : {'Authorization': 'Bearer $t'});
  }

  Future<Map<String, dynamic>> me() async {
    final r = await _dio.get('${AppConfig.customApi}/me', options: await _authOptions());
    return Map<String, dynamic>.from(r.data['user'] ?? {});
  }

  Future<void> updateMe(Map<String, dynamic> data) async {
    await _dio.post('${AppConfig.customApi}/me', data: data, options: await _authOptions());
  }

  Future<List<dynamic>> myOrders() async {
    final r = await _dio.get('${AppConfig.customApi}/me/orders', options: await _authOptions());
    return List<dynamic>.from((r.data as Map<String, dynamic>)['items'] ?? []);
  }

  Future<Map<String, dynamic>> trackOrder(String id, String phone) async {
    final r = await _dio.post('${AppConfig.customApi}/track-order', data: {'order_id': id, 'phone': phone});
    return Map<String, dynamic>.from(r.data);
  }

  Future<String?> _storedCartToken() async => cartToken ??= await _storage.read(key: 'cart_token');
  Future<void> _saveCartToken(Response r) async {
    final v = r.headers.value('Cart-Token');
    if (v != null && v.isNotEmpty) {
      cartToken = v;
      await _storage.write(key: 'cart_token', value: v);
    }
  }

  Future<Options> _cartOptions() async {
    final t = await _storedCartToken();
    return Options(headers: {if (t != null && t.isNotEmpty) 'Cart-Token': t});
  }

  Future<Map<String, dynamic>> cart() async {
    final r = await _dio.get('${AppConfig.storeApi}/cart', options: await _cartOptions());
    await _saveCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }

  Future<Map<String, dynamic>> addToCart(int productId, {int quantity = 1, List<Map<String, String>> variation = const []}) async {
    if ((await _storedCartToken()) == null) await cart();
    final body = <String, dynamic>{'id': productId, 'quantity': quantity};
    if (variation.isNotEmpty) body['variation'] = variation;
    final r = await _dio.post('${AppConfig.storeApi}/cart/add-item',
        data: body, options: await _cartOptions());
    await _saveCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }

  Future<Map<String, dynamic>> updateCartItem(String key, int quantity) async {
    final r = await _dio.post('${AppConfig.storeApi}/cart/update-item',
        data: {'key': key, 'quantity': quantity}, options: await _cartOptions());
    await _saveCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }

  Future<Map<String, dynamic>> removeCartItem(String key) async {
    final r = await _dio.post('${AppConfig.storeApi}/cart/remove-item',
        data: {'key': key}, options: await _cartOptions());
    await _saveCartToken(r);
    return Map<String, dynamic>.from(r.data);
  }
}

final api = ApiService();
