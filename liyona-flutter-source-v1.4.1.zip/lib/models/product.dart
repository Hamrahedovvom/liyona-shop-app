class Product {
  final int id;
  final String name;
  final String image;
  final String price;
  final String regularPrice;
  final String salePrice;
  final bool onSale;
  final bool inStock;
  final String stockStatus;
  final String type;
  final double averageRating;
  final int ratingCount;

  const Product({
    required this.id,
    required this.name,
    required this.image,
    required this.price,
    required this.regularPrice,
    required this.salePrice,
    required this.onSale,
    required this.inStock,
    required this.stockStatus,
    required this.type,
    required this.averageRating,
    required this.ratingCount,
  });

  factory Product.fromJson(Map<String, dynamic> j) => Product(
        id: (j['id'] as num?)?.toInt() ?? 0,
        name: (j['name'] ?? '').toString(),
        image: (j['image'] ?? '').toString(),
        price: (j['price'] ?? '').toString(),
        regularPrice: (j['regular_price'] ?? '').toString(),
        salePrice: (j['sale_price'] ?? '').toString(),
        onSale: j['on_sale'] == true,
        inStock: j['in_stock'] != false,
        stockStatus: (j['stock_status'] ?? '').toString(),
        type: (j['type'] ?? '').toString(),
        averageRating: double.tryParse((j['average_rating'] ?? '0').toString()) ?? 0,
        ratingCount: (j['rating_count'] as num?)?.toInt() ?? 0,
      );
}
