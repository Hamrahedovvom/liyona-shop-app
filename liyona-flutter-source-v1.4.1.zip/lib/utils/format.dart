import 'package:intl/intl.dart';

String money(dynamic value) {
  final raw = value?.toString() ?? '';
  final n = num.tryParse(raw);
  if (n == null) return raw;
  return '${NumberFormat.decimalPattern().format(n)} تومان';
}

String storeMoney(dynamic raw, {int minor = 0}) {
  final n = num.tryParse(raw?.toString() ?? '');
  if (n == null) return '';
  final value = minor > 0 ? n / (pow10(minor)) : n;
  return '${NumberFormat.decimalPattern().format(value)} تومان';
}

num pow10(int n) {
  num v = 1;
  for (var i = 0; i < n; i++) v *= 10;
  return v;
}
