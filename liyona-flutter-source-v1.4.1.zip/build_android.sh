#!/usr/bin/env bash
set -euo pipefail
flutter create . --platforms=android --org com.liyona
flutter pub get
dart run flutter_launcher_icons
dart run flutter_native_splash:create
flutter build apk --release
printf '\nAPK: build/app/outputs/flutter-apk/app-release.apk\n'
