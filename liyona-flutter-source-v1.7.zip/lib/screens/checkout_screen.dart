import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../services/api.dart';
import '../widgets/app_loader.dart';

class CheckoutScreen extends StatefulWidget {
  final Map<String, dynamic> cart;
  const CheckoutScreen({super.key, required this.cart});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  int step = 0;
  bool busy = false;
  String payment = '';
  late Future<Map<String, dynamic>> info;

  final first = TextEditingController();
  final last = TextEditingController();
  final phone = TextEditingController();
  final email = TextEditingController();
  final address = TextEditingController();
  final city = TextEditingController();
  final state = TextEditingController();
  final postcode = TextEditingController();

  @override
  void initState() {
    super.initState();
    info = api.checkoutInfo();
  }

  @override
  void dispose() {
    for (final c in [first, last, phone, email, address, city, state, postcode]) {
      c.dispose();
    }
    super.dispose();
  }

  Map<String, dynamic> get addr => {
        'first_name': first.text.trim(),
        'last_name': last.text.trim(),
        'company': '',
        'address_1': address.text.trim(),
        'address_2': '',
        'city': city.text.trim(),
        'state': state.text.trim(),
        'postcode': postcode.text.trim(),
        'country': 'IR',
        'email': email.text.trim(),
        'phone': phone.text.trim(),
      };

  Future<void> pay() async {
    if (first.text.trim().isEmpty ||
        last.text.trim().isEmpty ||
        phone.text.trim().isEmpty ||
        address.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اطلاعات ضروری را کامل کنید')),
      );
      return;
    }
    if (payment.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('روش پرداخت را انتخاب کنید')),
      );
      return;
    }

    setState(() => busy = true);
    try {
      final r = await api.checkout(billing: addr, shipping: addr, paymentMethod: payment);
      final pr = Map<String, dynamic>.from(r['payment_result'] ?? {});
      final url = (pr['redirect_url'] ?? '').toString();
      if (!mounted) return;
      if (url.isNotEmpty) {
        await Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => PaymentWebView(url: url)),
        );
        if (mounted) Navigator.pop(context, true);
      } else {
        await showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('سفارش ثبت شد'),
            content: Text('شماره سفارش: ${r['order_id'] ?? ''}'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('باشه')),
            ],
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('ثبت سفارش ناموفق بود\n$e')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تسویه حساب')),
        body: FutureBuilder<Map<String, dynamic>>(
          future: info,
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) return const LiyonaLoader();
            final data = s.data ?? {};
            final methods = List<dynamic>.from(data['payment_methods'] ?? []);
            if (payment.isEmpty && methods.isNotEmpty) payment = methods.first.toString();

            return Stepper(
              currentStep: step,
              onStepTapped: (v) => setState(() => step = v),
              controlsBuilder: (context, details) => Row(
                children: [
                  if (step < 2)
                    FilledButton(onPressed: () => setState(() => step++), child: const Text('ادامه')),
                  if (step > 0)
                    TextButton(onPressed: () => setState(() => step--), child: const Text('قبلی')),
                  if (step == 2)
                    FilledButton(
                      onPressed: busy ? null : pay,
                      child: Text(busy ? 'در حال ثبت...' : 'ثبت سفارش و پرداخت'),
                    ),
                ],
              ),
              steps: [
                Step(
                  title: const Text('آدرس و اطلاعات'),
                  isActive: step >= 0,
                  content: Column(
                    children: [
                      field(first, 'نام'),
                      field(last, 'نام خانوادگی'),
                      field(phone, 'موبایل', type: TextInputType.phone),
                      field(email, 'ایمیل', type: TextInputType.emailAddress),
                      field(address, 'آدرس'),
                      Row(
                        children: [
                          Expanded(child: field(city, 'شهر')),
                          const SizedBox(width: 8),
                          Expanded(child: field(state, 'استان')),
                        ],
                      ),
                      field(postcode, 'کد پستی', type: TextInputType.number),
                    ],
                  ),
                ),
                const Step(
                  title: Text('روش ارسال'),
                  isActive: true,
                  content: ListTile(
                    leading: Icon(Icons.local_shipping_outlined),
                    title: Text('ارسال فروشگاه لیونا'),
                    subtitle: Text('هزینه نهایی ارسال توسط ووکامرس محاسبه می‌شود'),
                  ),
                ),
                Step(
                  title: const Text('پرداخت'),
                  isActive: step >= 2,
                  content: methods.isEmpty
                      ? const Text('روش پرداخت فعال پیدا نشد')
                      : Column(
                          children: methods
                              .map(
                                (m) => RadioListTile<String>(
                                  value: m.toString(),
                                  groupValue: payment,
                                  onChanged: (v) => setState(() => payment = v ?? ''),
                                  title: Text(m.toString()),
                                ),
                              )
                              .toList(),
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget field(TextEditingController c, String label, {TextInputType? type}) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(controller: c, keyboardType: type, decoration: InputDecoration(labelText: label)),
      );
}

class PaymentWebView extends StatefulWidget {
  final String url;
  const PaymentWebView({super.key, required this.url});

  @override
  State<PaymentWebView> createState() => _PaymentWebViewState();
}

class _PaymentWebViewState extends State<PaymentWebView> {
  late final WebViewController controller;

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('پرداخت امن')),
        body: WebViewWidget(controller: controller),
      );
}
