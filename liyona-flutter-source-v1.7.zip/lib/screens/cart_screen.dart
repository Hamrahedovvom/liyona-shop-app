import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../services/api.dart';
import '../utils/format.dart';
import '../widgets/app_loader.dart';
import '../core/theme.dart';
import 'checkout_screen.dart';

class CartScreen extends StatefulWidget {
  final Future<void> Function()? onCartChanged;
  const CartScreen({super.key, this.onCartChanged});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  late Future<Map<String, dynamic>> future;
  final TextEditingController coupon = TextEditingController();

  @override
  void initState() {
    super.initState();
    future = api.cart();
  }

  @override
  void dispose() {
    coupon.dispose();
    super.dispose();
  }

  void reload() {
    setState(() => future = api.cart());
    widget.onCartChanged?.call();
  }

  double cartTotal(Map<String, dynamic> cart) {
    final totals = Map<String, dynamic>.from(cart['totals'] ?? {});
    final minor = int.tryParse((totals['currency_minor_unit'] ?? 0).toString()) ?? 0;
    final raw = num.tryParse((totals['total_items'] ?? totals['total_price'] ?? '0').toString()) ?? 0;
    final value = minor > 0 ? raw / pow10(minor) : raw;
    return value.toDouble();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: FutureBuilder<Map<String, dynamic>>(
        future: future,
        builder: (context, s) {
          if (s.connectionState != ConnectionState.done) return const LiyonaLoader();
          if (s.hasError) {
            return Center(child: FilledButton(onPressed: reload, child: const Text('تلاش دوباره')));
          }

          final cart = s.data ?? {};
          final items = List<dynamic>.from(cart['items'] ?? []);
          if (items.isEmpty) {
            return const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.shopping_bag_outlined, size: 76, color: Colors.black26),
                  SizedBox(height: 12),
                  Text('سبد خریدت خالیه', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                  SizedBox(height: 5),
                  Text('محصولات مورد علاقه‌ات رو اضافه کن'),
                ],
              ),
            );
          }

          final total = cartTotal(cart);
          final free = (total / 1000000).clamp(0.0, 1.0).toDouble();
          final remain = (1000000 - total).clamp(0, 1000000);

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 8),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'سبد خرید',
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900),
                      ),
                    ),
                    Text('${items.length} کالا'),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF5F8),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.local_shipping_outlined, color: LiyonaTheme.pink),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              total >= 1000000 ? 'ارسال شما رایگان شد 🎉' : 'فقط ${money(remain)} تا ارسال رایگان',
                              style: const TextStyle(fontWeight: FontWeight.w800),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      LiyonaProgress(value: free),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (_, i) {
                    final item = Map<String, dynamic>.from(items[i]);
                    final images = List<dynamic>.from(item['images'] ?? []);
                    final image = images.isNotEmpty
                        ? (Map<String, dynamic>.from(images.first)['src'] ?? '').toString()
                        : '';
                    final prices = Map<String, dynamic>.from(item['prices'] ?? {});
                    final minor = int.tryParse((prices['currency_minor_unit'] ?? 0).toString()) ?? 0;
                    final q = (item['quantity'] as num?)?.toInt() ?? 1;
                    final key = item['key'].toString();
                    final variation = List<dynamic>.from(item['variation'] ?? []);

                    return Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(15),
                                  child: SizedBox(
                                    width: 92,
                                    height: 92,
                                    child: image.isEmpty
                                        ? const Icon(Icons.image_outlined)
                                        : CachedNetworkImage(imageUrl: image, fit: BoxFit.cover),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        (item['name'] ?? '').toString(),
                                        maxLines: 2,
                                        style: const TextStyle(fontWeight: FontWeight.w900),
                                      ),
                                      if (variation.isNotEmpty)
                                        Padding(
                                          padding: const EdgeInsets.only(top: 5),
                                          child: Text(
                                            variation.map((e) {
                                              final m = Map<String, dynamic>.from(e);
                                              return '${m['attribute']}: ${m['value']}';
                                            }).join('، '),
                                            style: const TextStyle(fontSize: 11, color: Colors.black54),
                                          ),
                                        ),
                                      const SizedBox(height: 7),
                                      Text(
                                        storeMoney(prices['price'], minor: minor),
                                        textDirection: TextDirection.ltr,
                                        style: const TextStyle(color: LiyonaTheme.pink, fontWeight: FontWeight.w900),
                                      ),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  onPressed: () async {
                                    await api.removeCartItem(key);
                                    reload();
                                  },
                                  icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                                ),
                              ],
                            ),
                            const Divider(),
                            Row(
                              children: [
                                TextButton.icon(
                                  onPressed: () async {
                                    await api.saveForLater(item);
                                    await api.removeCartItem(key);
                                    reload();
                                  },
                                  icon: const Icon(Icons.bookmark_border, size: 18),
                                  label: const Text('خرید بعدی'),
                                ),
                                const Spacer(),
                                IconButton(
                                  onPressed: q > 1
                                      ? () async {
                                          await api.updateCartItem(key, q - 1);
                                          reload();
                                        }
                                      : null,
                                  icon: const Icon(Icons.remove_circle_outline),
                                ),
                                Text('$q', style: const TextStyle(fontWeight: FontWeight.w900)),
                                IconButton(
                                  onPressed: () async {
                                    await api.updateCartItem(key, q + 1);
                                    reload();
                                  },
                                  icon: const Icon(Icons.add_circle_outline),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(.06), blurRadius: 18)],
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: coupon,
                            decoration: const InputDecoration(hintText: 'کد تخفیف', isDense: true),
                          ),
                        ),
                        const SizedBox(width: 8),
                        FilledButton.tonal(
                          onPressed: () async {
                            if (coupon.text.trim().isEmpty) return;
                            try {
                              await api.applyCoupon(coupon.text.trim());
                              reload();
                            } catch (_) {
                              if (mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('کد تخفیف معتبر نیست')),
                                );
                              }
                            }
                          },
                          child: const Text('اعمال'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        const Text('جمع سبد', style: TextStyle(fontWeight: FontWeight.w800)),
                        const Spacer(),
                        Text(money(total), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: FilledButton(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => CheckoutScreen(cart: cart)),
                        ),
                        child: const Text('ادامه و تسویه حساب داخل اپ'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
