import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/product.dart';
import '../services/api.dart';
import '../core/theme.dart';
import '../utils/format.dart';
import '../widgets/app_loader.dart';
import '../widgets/html_content.dart';
import '../widgets/liyona_header.dart';
import 'cart_screen.dart';
import 'category_products_screen.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;
  const ProductDetailScreen({super.key, required this.product});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  late Future<Map<String, dynamic>> detail;
  final PageController galleryController = PageController();
  int imageIndex = 0;
  int qty = 1;
  bool adding = false;
  final Map<String, String> selected = {};

  @override
  void initState() {
    super.initState();
    detail = api.product(widget.product.id);
  }

  @override
  void dispose() {
    galleryController.dispose();
    super.dispose();
  }

  List<String> images(Map<String, dynamic> d) {
    final out = <String>[];
    final main = (d['image'] ?? '').toString();
    if (main.isNotEmpty) out.add(main);
    for (final e in List<dynamic>.from(d['gallery'] ?? [])) {
      final u = e.toString();
      if (u.isNotEmpty && !out.contains(u)) out.add(u);
    }
    return out;
  }

  String attrSlug(Map<String, dynamic> a) => (a['slug'] ?? a['name'] ?? '').toString();

  List<Map<String, String>> attrOptions(Map<String, dynamic> a) {
    final result = <Map<String, String>>[];
    for (final raw in List<dynamic>.from(a['options'] ?? [])) {
      if (raw is Map) {
        final m = Map<String, dynamic>.from(raw);
        final label = (m['label'] ?? m['name'] ?? m['value'] ?? '').toString();
        final value = (m['value'] ?? m['slug'] ?? label).toString();
        if (label.isNotEmpty) result.add({'label': label, 'value': value});
      } else {
        final value = raw.toString();
        if (value.isNotEmpty) result.add({'label': value, 'value': value});
      }
    }
    return result;
  }

  bool optionAvailable(Map<String, dynamic> d, String attr, String value) {
    final trial = Map<String, String>.from(selected)..[attr] = value;
    for (final raw in List<dynamic>.from(d['variations'] ?? [])) {
      final v = Map<String, dynamic>.from(raw);
      if (v['in_stock'] == false) continue;
      var ok = true;
      for (final rawAttr in List<dynamic>.from(v['attributes'] ?? [])) {
        final a = Map<String, dynamic>.from(rawAttr);
        final slug = (a['slug'] ?? a['name'] ?? '').toString();
        final vv = (a['value'] ?? a['option'] ?? '').toString();
        final chosen = trial[slug];
        if (vv.isNotEmpty && chosen != null && chosen.isNotEmpty && chosen != vv) { ok = false; break; }
      }
      if (ok) return true;
    }
    return false;
  }

  Map<String, dynamic>? matchedVariation(Map<String, dynamic> d) {
    final attrs = List<dynamic>.from(d['attributes'] ?? [])
        .map((e) => Map<String, dynamic>.from(e))
        .where((a) => a['variation'] == true)
        .toList();
    for (final a in attrs) {
      if ((selected[attrSlug(a)] ?? '').isEmpty) return null;
    }

    for (final raw in List<dynamic>.from(d['variations'] ?? [])) {
      final v = Map<String, dynamic>.from(raw);
      var ok = true;
      for (final rawAttr in List<dynamic>.from(v['attributes'] ?? [])) {
        final a = Map<String, dynamic>.from(rawAttr);
        final slug = (a['slug'] ?? a['name'] ?? '').toString();
        final value = (a['value'] ?? a['option'] ?? '').toString();
        if (value.isNotEmpty && selected[slug] != value) {
          ok = false;
          break;
        }
      }
      if (ok) return v;
    }
    return null;
  }

  Future<void> add(Map<String, dynamic> d) async {
    final attrs = List<dynamic>.from(d['attributes'] ?? [])
        .map((e) => Map<String, dynamic>.from(e))
        .where((a) => a['variation'] == true)
        .toList();

    for (final a in attrs) {
      final slug = attrSlug(a);
      if ((selected[slug] ?? '').isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('لطفاً ${a['name'] ?? 'گزینه محصول'} را انتخاب کنید')),
        );
        return;
      }
    }

    final isVariable = (d['type'] ?? '') == 'variable';
    final variation = isVariable ? matchedVariation(d) : null;
    if (isVariable && variation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('این ترکیب از گزینه‌ها موجود نیست')),
      );
      return;
    }
    if (variation != null && variation['in_stock'] == false) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('این گزینه در حال حاضر ناموجود است')),
      );
      return;
    }

    setState(() => adding = true);
    try {
      final id = variation == null ? widget.product.id : (variation['id'] as num).toInt();
      final variationPayload = attrs.map((a) {
        final slug = attrSlug(a);
        return {'attribute': slug, 'value': selected[slug] ?? ''};
      }).toList();
      await api.addToCart(id, quantity: qty, variation: variationPayload);
      if (!mounted) return;
      await _showAddedDialog(d);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('افزودن به سبد خرید ناموفق بود\n$e')),
      );
    } finally {
      if (mounted) setState(() => adding = false);
    }
  }

  Future<void> _showAddedDialog(Map<String, dynamic> d) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => Container(
        margin: const EdgeInsets.all(12),
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 20),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: const BoxDecoration(color: Color(0xFFFFE4EE), shape: BoxShape.circle),
                child: const Icon(Icons.check_rounded, color: LiyonaTheme.pink, size: 32),
              ),
              const SizedBox(height: 10),
              const Text('به سبد خرید اضافه شد', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text(
                (d['name'] ?? widget.product.name).toString(),
                maxLines: 2,
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
              ),
              if (selected.isNotEmpty) ...[
                const SizedBox(height: 6),
                Text(
                  selected.values.join(' • '),
                  style: const TextStyle(color: Colors.black54, fontWeight: FontWeight.w700),
                ),
              ],
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(sheetContext),
                      child: const Text('ادامه خرید'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton(
                      onPressed: () {
                        Navigator.pop(sheetContext);
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen()));
                      },
                      child: const Text('رفتن به سبد خرید'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: LiyonaHeader(
          onBack: () => Navigator.pop(context),
          onCart: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())),
        ),
        body: FutureBuilder<Map<String, dynamic>>(
          future: detail,
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) return const LiyonaLoader();
            if (s.hasError) return const Center(child: Text('دریافت اطلاعات محصول ناموفق بود'));

            final d = s.data ?? {};
            final gallery = images(d);
            final attrs = List<dynamic>.from(d['attributes'] ?? [])
                .map((e) => Map<String, dynamic>.from(e))
                .where((a) => a['variation'] == true)
                .toList();
            final variation = matchedVariation(d);
            final shownPrice = (variation?['price'] ?? d['price'] ?? '').toString();
            final desc = (d['description'] ?? '').toString();
            final short = (d['short_description'] ?? '').toString();
            final cats = List<dynamic>.from(d['categories'] ?? []);
            final tags = List<dynamic>.from(d['tags'] ?? []);

            return ListView(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 110),
              children: [
                if (cats.isNotEmpty) ...[
                  Builder(builder: (context) {
                    final mapped = cats.map((e) => Map<String, dynamic>.from(e)).toList();
                    mapped.sort((a, b) => List<dynamic>.from(b['path'] ?? []).length.compareTo(List<dynamic>.from(a['path'] ?? []).length));
                    final path = List<dynamic>.from(mapped.first['path'] ?? [mapped.first]);
                    return SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      reverse: true,
                      child: Row(
                        children: List.generate(path.length, (i) {
                          final c = Map<String, dynamic>.from(path[i]);
                          final name = (c['name'] ?? '').toString();
                          final slug = (c['slug'] ?? '').toString();
                          return Row(children: [
                            TextButton(
                              onPressed: slug.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryProductsScreen(name: name, slug: slug))),
                              child: Text(name, style: const TextStyle(fontWeight: FontWeight.w800)),
                            ),
                            if (i < path.length - 1) const Icon(Icons.chevron_left_rounded, size: 17, color: Colors.black38),
                          ]);
                        }),
                      ),
                    );
                  }),
                  const SizedBox(height: 6),
                ],
                if (gallery.isNotEmpty) ...[
                  AspectRatio(
                      aspectRatio: 1,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: const Color(0xFFEAE6E8)),
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: PageView.builder(
                          controller: galleryController,
                          itemCount: gallery.length,
                          onPageChanged: (v) => setState(() => imageIndex = v),
                          itemBuilder: (_, i) => InkWell(
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => GalleryScreen(images: gallery, initial: i)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: CachedNetworkImage(imageUrl: gallery[i], fit: BoxFit.contain),
                            ),
                          ),
                        ),
                      ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 82,
                    child: ListView.separated(
                      reverse: true,
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      itemCount: gallery.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (_, i) => InkWell(
                        borderRadius: BorderRadius.circular(14),
                        onTap: () {
                          setState(() => imageIndex = i);
                          galleryController.animateToPage(
                            i,
                            duration: const Duration(milliseconds: 280),
                            curve: Curves.easeOutCubic,
                          );
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          width: 78,
                          height: 78,
                          padding: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: i == imageIndex ? LiyonaTheme.pink : const Color(0xFFE5E2E4),
                              width: i == imageIndex ? 2.2 : 1,
                            ),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: CachedNetworkImage(imageUrl: gallery[i], fit: BoxFit.cover),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Container(
                      margin: const EdgeInsets.only(top: 7),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(color: const Color(0xFFF4F1F2), borderRadius: BorderRadius.circular(12)),
                      child: Text('${imageIndex + 1} / ${gallery.length}'),
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        (d['name'] ?? widget.product.name).toString(),
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, height: 1.5),
                      ),
                    ),
                    IconButton(onPressed: () {}, icon: const Icon(Icons.favorite_border_rounded)),
                    IconButton(onPressed: () {}, icon: const Icon(Icons.ios_share_rounded)),
                  ],
                ),
                if ((d['average_rating'] ?? '0').toString() != '0')
                  Row(
                    children: [
                      const Icon(Icons.star_rounded, color: Colors.amber, size: 20),
                      Text(' ${d['average_rating']}  '),
                      Text('${d['review_count'] ?? 0} نظر', style: const TextStyle(color: Colors.black54)),
                    ],
                  ),
                const SizedBox(height: 8),
                Text(
                  money(shownPrice),
                  style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: LiyonaTheme.pink),
                ),
                if (variation != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Text(
                      variation['in_stock'] == false ? 'ناموجود' : 'موجود و آماده ارسال',
                      style: TextStyle(
                        color: variation['in_stock'] == false ? Colors.red : Colors.green.shade700,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                if (short.isNotEmpty) ...[
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: const Color(0xFFFAF8F9), borderRadius: BorderRadius.circular(18)),
                    child: HtmlContent(html: short),
                  ),
                ],
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: const Color(0xFFFFF3F7), borderRadius: BorderRadius.circular(18)),
                  child: const Row(
                    children: [
                      Icon(Icons.verified_outlined, color: LiyonaTheme.pink),
                      SizedBox(width: 8),
                      Expanded(child: Text('ضمانت اصالت کالا  •  ارسال سریع  •  خرید امن', style: TextStyle(fontWeight: FontWeight.w700))),
                    ],
                  ),
                ),
                if (attrs.isNotEmpty) ...[
                  const SizedBox(height: 22),
                  const Text('انتخاب ویژگی‌ها', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  ...attrs.map((a) {
                    final slug = attrSlug(a);
                    final options = attrOptions(a);
                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: const Color(0xFFE8E3E6)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text((a['name'] ?? '').toString(), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: options.map((o) {
                              final value = o['value'] ?? '';
                              final isSelected = selected[slug] == value;
                              final available = optionAvailable(d, slug, value);
                              return ChoiceChip(
                                avatar: available ? null : const Icon(Icons.close_rounded, size: 16, color: Colors.black38),
                                label: Text(o['label'] ?? ''),
                                selected: isSelected,
                                showCheckmark: false,
                                selectedColor: const Color(0xFFFFDDE9),
                                disabledColor: const Color(0xFFF1EFF0),
                                side: BorderSide(color: isSelected ? LiyonaTheme.pink : const Color(0xFFD8D3D6)),
                                labelStyle: TextStyle(
                                  decoration: available ? null : TextDecoration.lineThrough,
                                  color: !available ? Colors.black38 : (isSelected ? LiyonaTheme.pink : const Color(0xFF332F31)),
                                  fontWeight: isSelected ? FontWeight.w900 : FontWeight.w700,
                                ),
                                onSelected: available ? (_) => setState(() => selected[slug] = value) : null,
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                    );
                  }),
                ],
                Container(
                  margin: const EdgeInsets.only(top: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(color: const Color(0xFFFAF8F9), borderRadius: BorderRadius.circular(18)),
                  child: Row(
                    children: [
                      const Text('تعداد', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                      const Spacer(),
                      IconButton(onPressed: qty > 1 ? () => setState(() => qty--) : null, icon: const Icon(Icons.remove_circle_outline_rounded)),
                      Text('$qty', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                      IconButton(onPressed: () => setState(() => qty++), icon: const Icon(Icons.add_circle_outline_rounded)),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                ExpansionSection(
                  title: 'توضیحات محصول',
                  child: desc.isEmpty ? const Text('توضیحی ثبت نشده') : HtmlContent(html: desc),
                ),
                ExpansionSection(
                  title: 'مشخصات و اطلاعات',
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (cats.isNotEmpty)
                        MetaRow(title: 'دسته‌بندی', items: cats.map((e) => Map<String, dynamic>.from(e)['name'].toString()).toList()),
                      if (tags.isNotEmpty)
                        MetaRow(title: 'برچسب‌ها', items: tags.map((e) => Map<String, dynamic>.from(e)['name'].toString()).toList()),
                      if ((d['sku'] ?? '').toString().isNotEmpty) Text('کد محصول: ${d['sku']}'),
                    ],
                  ),
                ),
                ExpansionSection(title: 'نظرات کاربران', child: ReviewsList(productId: widget.product.id)),
              ],
            );
          },
        ),
        bottomNavigationBar: SafeArea(
          child: Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
            child: FutureBuilder<Map<String, dynamic>>(
              future: detail,
              builder: (context, s) => SizedBox(
                height: 56,
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: adding || !s.hasData ? null : () => add(s.data!),
                  icon: const Icon(Icons.shopping_bag_outlined),
                  label: Text(adding ? 'در حال افزودن...' : 'افزودن به سبد خرید'),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class GalleryScreen extends StatefulWidget {
  final List<String> images;
  final int initial;
  const GalleryScreen({super.key, required this.images, required this.initial});
  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  late PageController controller;
  late int index;
  @override
  void initState() {
    super.initState();
    index = widget.initial;
    controller = PageController(initialPage: index);
  }
  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
            foregroundColor: Colors.white,
            title: Text('${index + 1} / ${widget.images.length}'),
          ),
          body: PageView.builder(
            controller: controller,
            onPageChanged: (v) => setState(() => index = v),
            itemCount: widget.images.length,
            itemBuilder: (_, i) => InteractiveViewer(
              minScale: 1,
              maxScale: 5,
              child: Center(child: CachedNetworkImage(imageUrl: widget.images[i], fit: BoxFit.contain)),
            ),
          ),
        ),
      );
}

class ExpansionSection extends StatelessWidget {
  final String title;
  final Widget child;
  const ExpansionSection({super.key, required this.title, required this.child});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE8E3E6)),
        ),
        child: ExpansionTile(
          shape: const Border(),
          collapsedShape: const Border(),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
          children: [Padding(padding: const EdgeInsets.fromLTRB(14, 0, 14, 14), child: child)],
        ),
      );
}

class MetaRow extends StatelessWidget {
  final String title;
  final List<String> items;
  const MetaRow({super.key, required this.title, required this.items});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('$title:', style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 7),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: items.map((e) => Chip(label: Text(e), visualDensity: VisualDensity.compact)).toList(),
            ),
          ],
        ),
      );
}

class ReviewsList extends StatelessWidget {
  final int productId;
  const ReviewsList({super.key, required this.productId});
  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
        future: api.productReviews(productId),
        builder: (context, s) {
          if (s.connectionState != ConnectionState.done) return const Padding(padding: EdgeInsets.all(16), child: LiyonaLoader(size: 52));
          final items = s.data ?? [];
          if (items.isEmpty) return const Text('هنوز نظری ثبت نشده');
          return Column(
            children: items.take(8).map((raw) {
              final r = Map<String, dynamic>.from(raw);
              return Card(
                child: ListTile(
                  title: Row(
                    children: [
                      Expanded(child: Text((r['author'] ?? 'کاربر').toString(), style: const TextStyle(fontWeight: FontWeight.w800))),
                      const Icon(Icons.star, color: Colors.amber, size: 17),
                      Text((r['rating'] ?? '').toString()),
                    ],
                  ),
                  subtitle: Text((r['review'] ?? '').toString()),
                ),
              );
            }).toList(),
          );
        },
      );
}
