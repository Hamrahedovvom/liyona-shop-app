import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/theme.dart';

Future<void> showContactSheet(BuildContext context) async {
  Future<void> open(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  await showModalBottomSheet(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (_) => Directionality(
      textDirection: TextDirection.rtl,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('تماس با لیونا', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              const Text('هر راهی راحت‌تری انتخاب کن', style: TextStyle(color: Colors.black54)),
              const SizedBox(height: 14),
              _ContactTile(icon: Icons.phone_outlined, title: 'تماس مستقیم', subtitle: '09220024591', onTap: () => open('tel:09220024591')),
              _ContactTile(icon: Icons.chat_bubble_outline, title: 'واتساپ', subtitle: '09220024591', onTap: () => open('https://wa.me/989220024591')),
              _ContactTile(icon: Icons.send_outlined, title: 'تلگرام', subtitle: '@Poshtibanisite', onTap: () => open('https://t.me/Poshtibanisite')),
              _ContactTile(icon: Icons.email_outlined, title: 'ایمیل', subtitle: 'ali.org.f@gmail.com', onTap: () => open('mailto:ali.org.f@gmail.com')),
              _ContactTile(icon: Icons.camera_alt_outlined, title: 'اینستاگرام', subtitle: '@Liyona_shop', onTap: () => open('https://instagram.com/Liyona_shop')),
            ],
          ),
        ),
      ),
    ),
  );
}

class _ContactTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _ContactTile({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(color: const Color(0xFFFFF7FA), borderRadius: BorderRadius.circular(18)),
        child: ListTile(
          leading: CircleAvatar(backgroundColor: const Color(0xFFFFE1EC), child: Icon(icon, color: LiyonaTheme.pink)),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(subtitle, textDirection: TextDirection.ltr),
          trailing: const Icon(Icons.chevron_left),
          onTap: onTap,
        ),
      );
}
