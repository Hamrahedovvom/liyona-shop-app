import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import '../services/api.dart';
import '../core/theme.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController();
  final code = TextEditingController();
  bool sent = false, busy = false;
  String? error;
  int seconds = 0;
  Timer? timer;

  void startTimer() {
    timer?.cancel();
    setState(() => seconds = 60);
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return t.cancel();
      if (seconds <= 1) { t.cancel(); setState(() => seconds = 0); }
      else setState(() => seconds--);
    });
  }

  String errorText(Object e) {
    if (e is DioException) {
      final data = e.response?.data;
      if (data is Map) return (data['message'] ?? data['error'] ?? 'خطا در ارتباط با سرور').toString();
    }
    return 'خطا در ارتباط با سرور. دوباره تلاش کنید.';
  }

  Future<void> requestCode() async {
    final normalized = api.normalizePhone(phone.text);
    if (!RegExp(r'^09\d{9}$').hasMatch(normalized)) {
      setState(() => error = 'شماره موبایل را به‌صورت صحیح وارد کنید'); return;
    }
    setState(() { busy = true; error = null; });
    try { await api.requestOtp(normalized); if (mounted) { setState(() => sent = true); startTimer(); } }
    catch (e) { if (mounted) setState(() => error = errorText(e)); }
    finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> verify() async {
    if (code.text.trim().length < 4) { setState(() => error = 'کد تایید را وارد کنید'); return; }
    setState(() { busy = true; error = null; });
    try { await api.verifyOtp(phone.text, code.text.trim()); if (mounted) Navigator.pop(context, true); }
    catch (e) { if (mounted) setState(() => error = errorText(e)); }
    finally { if (mounted) setState(() => busy = false); }
  }

  @override void dispose() { timer?.cancel(); phone.dispose(); code.dispose(); super.dispose(); }

  @override Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(24), children: [
        Image.asset('assets/images/liyona_logo.png', height: 84, fit: BoxFit.contain),
        const SizedBox(height: 18),
        const Text('ورود به حساب لیونا', textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        const Text('ورود و عضویت با شماره موبایل', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 28),
        TextField(controller: phone, enabled: !sent, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'شماره موبایل', hintText: '09123456789')),
        if (sent) ...[
          const SizedBox(height: 14),
          TextField(controller: code, keyboardType: TextInputType.number, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'کد تایید')),
          const SizedBox(height: 8),
          TextButton(onPressed: seconds == 0 && !busy ? requestCode : null, child: Text(seconds > 0 ? 'ارسال مجدد تا $seconds ثانیه' : 'ارسال مجدد کد')),
        ],
        if (error != null) ...[const SizedBox(height: 10), Text(error!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center)],
        const SizedBox(height: 18),
        FilledButton(onPressed: busy ? null : (sent ? verify : requestCode), style: FilledButton.styleFrom(padding: const EdgeInsets.all(16), backgroundColor: LiyonaTheme.pink), child: Text(busy ? 'لطفاً صبر کنید...' : sent ? 'تایید و ورود' : 'دریافت کد تایید')),
      ])),
    ),
  );
}
