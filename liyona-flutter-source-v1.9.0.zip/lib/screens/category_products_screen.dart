import 'package:flutter/material.dart';
import '../models/product.dart';
import '../services/api.dart';
import '../widgets/app_loader.dart';
import '../widgets/explore_grid.dart';
import '../widgets/liyona_header.dart';
import 'cart_screen.dart';

class CategoryProductsScreen extends StatefulWidget {
  final String name;
  final String slug;
  const CategoryProductsScreen({super.key, required this.name, required this.slug});

  @override
  State<CategoryProductsScreen> createState() => _CategoryProductsScreenState();
}

class _CategoryProductsScreenState extends State<CategoryProductsScreen> {
  int page = 1;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: LiyonaHeader(
          onBack: () => Navigator.pop(context),
          onCart: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())),
        ),
        body: FutureBuilder<Map<String, dynamic>>(
          future: api.productsPage(category: widget.slug, page: page, perPage: 20),
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) return const LiyonaLoader();
            if (s.hasError) return const Center(child: Text('دریافت محصولات ناموفق بود'));
            final data = s.data ?? {};
            final items = List<Product>.from(data['items'] ?? const <Product>[]);
            final pages = (data['pages'] as int?) ?? 1;
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(widget.name, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
                      ),
                      Text('${(data['total'] as int?) ?? items.length} محصول'),
                    ],
                  ),
                ),
                Expanded(
                  child: items.isEmpty
                      ? const Center(child: Text('محصولی در این دسته پیدا نشد'))
                      : ExploreGrid(products: items, shrinkWrap: false, padding: EdgeInsets.zero),
                ),
                if (pages > 1)
                  SafeArea(
                    top: false,
                    child: Container(
                      color: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                            onPressed: page > 1 ? () => setState(() => page--) : null,
                            icon: const Icon(Icons.chevron_right_rounded),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFE7EF),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Text('صفحه $page از $pages', style: const TextStyle(fontWeight: FontWeight.w900)),
                          ),
                          IconButton(
                            onPressed: page < pages ? () => setState(() => page++) : null,
                            icon: const Icon(Icons.chevron_left_rounded),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}
