import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../services/api.dart';
import '../widgets/app_loader.dart';
import '../widgets/liyona_header.dart';
import 'category_products_screen.dart';
import 'cart_screen.dart';

class CategoriesScreen extends StatelessWidget {
  final ValueChanged<int>? onSelectTab;
  const CategoriesScreen({super.key, this.onSelectTab});

  @override
  Widget build(BuildContext context) => _CategoryLevel(
        parentId: 0,
        title: 'دسته‌بندی‌ها',
        root: true,
        onSelectTab: onSelectTab,
      );
}

class _CategoryLevel extends StatelessWidget {
  final int parentId;
  final String title;
  final bool root;
  final ValueChanged<int>? onSelectTab;
  const _CategoryLevel({required this.parentId, required this.title, this.root = false, this.onSelectTab});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: LiyonaHeader(
          onBack: root ? null : () => Navigator.pop(context),
          onAccount: root && onSelectTab != null ? () => onSelectTab!(3) : null,
          onCart: root && onSelectTab != null
              ? () => onSelectTab!(2)
              : () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())),
        ),
        body: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
                child: Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              ),
            ),
            FutureBuilder<List<dynamic>>(
              future: api.categories(parent: parentId),
              builder: (context, s) {
                if (s.connectionState != ConnectionState.done) {
                  return const SliverFillRemaining(child: LiyonaLoader());
                }
                final items = s.data ?? [];
                if (items.isEmpty) {
                  return const SliverFillRemaining(child: Center(child: Text('دسته‌ای برای نمایش نیست')));
                }
                return SliverPadding(
                  padding: const EdgeInsets.fromLTRB(12, 4, 12, 110),
                  sliver: SliverGrid(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: .90,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (context, i) {
                        final c = Map<String, dynamic>.from(items[i]);
                        final image = (c['image'] ?? '').toString();
                        final hasChildren = c['has_children'] == true;
                        return InkWell(
                          borderRadius: BorderRadius.circular(22),
                          onTap: () {
                            final name = (c['name'] ?? '').toString();
                            if (hasChildren) {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => _CategoryLevel(
                                    parentId: (c['id'] as num).toInt(),
                                    title: name,
                                    onSelectTab: onSelectTab,
                                  ),
                                ),
                              );
                            } else {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => CategoryProductsScreen(
                                    name: name,
                                    slug: (c['slug'] ?? '').toString(),
                                  ),
                                ),
                              );
                            }
                          },
                          child: Card(
                            clipBehavior: Clip.antiAlias,
                            child: Column(
                              children: [
                                Expanded(
                                  child: SizedBox.expand(
                                    child: image.isEmpty
                                        ? const ColoredBox(
                                            color: Color(0xFFFFEEF4),
                                            child: Icon(Icons.category_outlined, size: 46),
                                          )
                                        : CachedNetworkImage(imageUrl: image, fit: BoxFit.cover),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(10, 10, 10, 12),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          (c['name'] ?? '').toString(),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(fontWeight: FontWeight.w900),
                                        ),
                                      ),
                                      if (hasChildren) const Icon(Icons.chevron_left_rounded, size: 20),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                      childCount: items.length,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
