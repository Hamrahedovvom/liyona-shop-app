import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../services/api.dart';
import '../core/theme.dart';
import '../utils/format.dart';
import 'login_screen.dart';
import 'orders_screen.dart';

class CheckoutScreen extends StatefulWidget {
  final Map<String, dynamic> cart;
  const CheckoutScreen({super.key, required this.cart});
  @override State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final first=TextEditingController(), last=TextEditingController(), phone=TextEditingController(), email=TextEditingController(), address=TextEditingController(), city=TextEditingController(), state=TextEditingController(), postcode=TextEditingController();
  bool busy=false, ready=false; String payment=''; List<Map<String,dynamic>> methods=[];
  @override void initState(){super.initState(); _prepare();}
  Future<void> _prepare() async {
    if (!await api.isLoggedIn()) {
      if (!mounted) return;
      final ok=await Navigator.push<bool>(context,MaterialPageRoute(builder:(_)=>const LoginScreen()));
      if(ok!=true){if(mounted) Navigator.pop(context);return;}
    }
    try {
      final u=await api.me();
      first.text=(u['first_name']??'').toString(); last.text=(u['last_name']??'').toString(); phone.text=(u['phone']??u['billing_phone']??'').toString(); email.text=(u['email']??'').toString();
      methods=await api.paymentMethods(); if(methods.isNotEmpty) payment=(methods.first['id']??'').toString();
    } catch (_) {}
    if(mounted)setState(()=>ready=true);
  }
  @override void dispose(){for(final c in [first,last,phone,email,address,city,state,postcode]){c.dispose();}super.dispose();}
  Map<String,dynamic> get addr=>{'first_name':first.text.trim(),'last_name':last.text.trim(),'company':'','address_1':address.text.trim(),'address_2':'','city':city.text.trim(),'state':state.text.trim(),'postcode':postcode.text.trim(),'country':'IR','email':email.text.trim(),'phone':phone.text.trim()};
  double total(){final t=Map<String,dynamic>.from(widget.cart['totals']??{}); final minor=int.tryParse('${t['currency_minor_unit']??0}')??0; final raw=num.tryParse('${t['total_price']??t['total_items']??0}')??0; return (minor>0?raw/pow10(minor):raw).toDouble();}
  Future<void> pay() async {
    if([first,last,phone,address].any((c)=>c.text.trim().isEmpty)){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('اطلاعات ضروری را کامل کنید')));return;}
    if(payment.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('روش پرداخت را انتخاب کنید')));return;}
    setState(()=>busy=true);
    try{
      await api.updateCustomer(billing:addr,shipping:addr);
      final r=await api.checkout(billing:addr,shipping:addr,paymentMethod:payment); final id=(r['order_id'] as num?)?.toInt()??0; final pr=Map<String,dynamic>.from(r['payment_result']??{}); final url=(pr['redirect_url']??'').toString();
      if(!mounted)return;
      if(url.isNotEmpty) await Navigator.push(context,MaterialPageRoute(builder:(_)=>PaymentWebView(url:url)));
      Map<String,dynamic> status={}; if(id>0){try{status=await api.orderStatus(id);}catch(_){}}
      final st=(status['status']??r['status']??'').toString(); final success=url.isEmpty || ['processing','completed','on-hold'].contains(st);
      if(!mounted)return;
      Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>ThankYouScreen(orderId:id,success:success,status:(status['status_label']??st).toString(),total:(status['total']??total()).toString())));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('ثبت سفارش ناموفق بود\n$e')));}finally{if(mounted)setState(()=>busy=false);}
  }
  Widget field(TextEditingController c,String label,{TextInputType? type})=>Padding(padding:const EdgeInsets.only(bottom:10),child:TextField(controller:c,keyboardType:type,decoration:InputDecoration(labelText:label,filled:true,fillColor:Colors.white)));
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('تسویه حساب')),
    body:!ready?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.fromLTRB(16,12,16,130),children:[
      _card('اطلاعات گیرنده',Icons.person_outline,Column(children:[Row(children:[Expanded(child:field(first,'نام')),const SizedBox(width:8),Expanded(child:field(last,'نام خانوادگی'))]),field(phone,'شماره موبایل',type:TextInputType.phone),field(email,'ایمیل',type:TextInputType.emailAddress)])),
      _card('آدرس ارسال',Icons.location_on_outlined,Column(children:[field(address,'آدرس کامل'),Row(children:[Expanded(child:field(state,'استان')),const SizedBox(width:8),Expanded(child:field(city,'شهر'))]),field(postcode,'کد پستی',type:TextInputType.number)])),
      _card('روش ارسال',Icons.local_shipping_outlined,const ListTile(contentPadding:EdgeInsets.zero,title:Text('ارسال فروشگاه لیونا',style:TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('هزینه ارسال بر اساس سبد و آدرس توسط ووکامرس محاسبه می‌شود'))),
      _card('روش پرداخت',Icons.credit_card_outlined,methods.isEmpty?const Padding(padding:EdgeInsets.all(12),child:Text('روش پرداخت فعالی از ووکامرس دریافت نشد')):Column(children:methods.map((m)=>RadioListTile<String>(value:(m['id']??'').toString(),groupValue:payment,onChanged:(v)=>setState(()=>payment=v??''),title:Text((m['title']??m['id']??'').toString(),style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:(m['description']??'').toString().isEmpty?null:Text((m['description']??'').toString()))).toList())),
    ]),
    bottomNavigationBar:SafeArea(child:Container(padding:const EdgeInsets.fromLTRB(16,10,16,12),decoration:const BoxDecoration(color:Colors.white,boxShadow:[BoxShadow(color:Color(0x18000000),blurRadius:18)]),child:Row(children:[Expanded(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('مبلغ نهایی',style:TextStyle(color:Colors.black54)),Text(money(total()),style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:LiyonaTheme.pink))])),Expanded(flex:2,child:FilledButton(onPressed:busy?null:pay,style:FilledButton.styleFrom(minimumSize:const Size(0,54)),child:Text(busy?'در حال ثبت...':'ثبت سفارش و پرداخت')))]))),
  );
  Widget _card(String title,IconData icon,Widget child)=>Container(margin:const EdgeInsets.only(bottom:14),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:const Color(0xFFFFF9FB),borderRadius:BorderRadius.circular(22),border:Border.all(color:const Color(0xFFF0E5EA))),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Row(children:[Icon(icon,color:LiyonaTheme.pink),const SizedBox(width:8),Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900))]),const SizedBox(height:12),child]));
}

class PaymentWebView extends StatefulWidget{final String url;const PaymentWebView({super.key,required this.url});@override State<PaymentWebView> createState()=>_PaymentWebViewState();}
class _PaymentWebViewState extends State<PaymentWebView>{late final WebViewController controller;@override void initState(){super.initState();controller=WebViewController()..setJavaScriptMode(JavaScriptMode.unrestricted)..setNavigationDelegate(NavigationDelegate(onNavigationRequest:(r){final u=r.url.toLowerCase();if(u.contains('order-received')||u.contains('thankyou')){Navigator.pop(context,true);return NavigationDecision.prevent;}return NavigationDecision.navigate;}))..loadRequest(Uri.parse(widget.url));}@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('پرداخت امن')),body:WebViewWidget(controller:controller));}

class ThankYouScreen extends StatelessWidget{final int orderId;final bool success;final String status,total;const ThankYouScreen({super.key,required this.orderId,required this.success,required this.status,required this.total});@override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Container(width:86,height:86,decoration:BoxDecoration(color:success?const Color(0xFFE8F8EE):const Color(0xFFFFECEC),shape:BoxShape.circle),child:Icon(success?Icons.check_rounded:Icons.info_outline_rounded,size:52,color:success?Colors.green:Colors.redAccent)),const SizedBox(height:20),Text(success?'خرید با موفقیت انجام شد':'وضعیت پرداخت نیاز به بررسی دارد',textAlign:TextAlign.center,style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900)),const SizedBox(height:12),Text('شماره سفارش: #$orderId\nوضعیت: $status\nمبلغ: ${money(total)}',textAlign:TextAlign.center,style:const TextStyle(height:1.9,fontSize:16)),const SizedBox(height:26),SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const OrdersScreen())),child:const Text('مشاهده سفارش‌های من'))),TextButton(onPressed:()=>Navigator.popUntil(context,(r)=>r.isFirst),child:const Text('بازگشت به فروشگاه'))]))));}
