import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/api.dart';
import '../core/theme.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});
  @override State<OrdersScreen> createState()=>_OrdersScreenState();
}
class _OrdersScreenState extends State<OrdersScreen>{
  late Future<List<dynamic>> future;
  @override void initState(){super.initState();future=api.myOrders();}
  Future<void> reload() async {setState(()=>future=api.myOrders());await future;}
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('سفارش‌های من')),
    body:FutureBuilder<List<dynamic>>(
      future:future,
      builder:(c,s){
        if(s.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());
        if(s.hasError)return const Center(child:Text('برای مشاهده سفارش‌ها وارد حساب کاربری شوید'));
        final a=s.data??[]; if(a.isEmpty)return const Center(child:Text('هنوز سفارشی ندارید'));
        return RefreshIndicator(
          onRefresh:reload,
          child:ListView.separated(
            padding:const EdgeInsets.all(16),
            itemCount:a.length,
            separatorBuilder:(_,__)=>const SizedBox(height:12),
            itemBuilder:(_,i){
              final o=Map<String,dynamic>.from(a[i]);
              final tracking=(o['tracking_code']??o['tracking_number']??'').toString();
              final status=(o['status_label']??o['status']??'').toString();
              return Container(
                padding:const EdgeInsets.all(15),
                decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(20),border:Border.all(color:const Color(0xFFF0E6EA))),
                child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
                  Row(children:[Expanded(child:Text('سفارش #${o['number']??o['id']}',style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900))),Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:5),decoration:BoxDecoration(color:const Color(0xFFFFEDF4),borderRadius:BorderRadius.circular(20)),child:Text(status,style:const TextStyle(color:LiyonaTheme.pink,fontWeight:FontWeight.w800)))]),
                  const SizedBox(height:10),
                  Text('مبلغ: ${o['total']??''} ${o['currency']??''}'),
                  if((o['date_created']??'').toString().isNotEmpty)Text('تاریخ: ${o['date_created']}',style:const TextStyle(color:Colors.black54)),
                  if(tracking.isNotEmpty)...[
                    const Divider(height:24),
                    Row(children:[const Icon(Icons.local_shipping_outlined,color:LiyonaTheme.pink),const SizedBox(width:8),Expanded(child:Text('کد رهگیری پستی: $tracking',style:const TextStyle(fontWeight:FontWeight.w800))),TextButton(onPressed:()async{final link=(o['tracking_url']??'https://tracking.post.ir/').toString();await launchUrl(Uri.parse(link),mode:LaunchMode.externalApplication);},child:const Text('پیگیری مرسوله'))])
                  ]
                ]),
              );
            },
          ),
        );
      },
    ),
  );
}
