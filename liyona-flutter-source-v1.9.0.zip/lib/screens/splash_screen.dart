import 'dart:async';
import 'package:flutter/material.dart';
import '../core/theme.dart';
import 'main_shell.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 1500), () {
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainShell()));
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(colors: [Colors.white, Color(0xFFFFEDF4), Color(0xFFF0F6FF)], begin: Alignment.topRight, end: Alignment.bottomLeft),
      ),
      child: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Image.asset('assets/images/liyona_logo.png', width: 220, height: 110, fit: BoxFit.contain),
          const SizedBox(height: 16),
          const Text('Liyona', style: TextStyle(fontSize: 46, fontWeight: FontWeight.w800, color: LiyonaTheme.blue)),
          const SizedBox(height: 8),
          Text('زیبایی در سبک زندگی تو', style: Theme.of(context).textTheme.titleMedium),
        ]),
      ),
    ),
  );
}
