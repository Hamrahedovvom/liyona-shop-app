import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class LiyonaTheme {
  static const pink = Color(0xFFE50064);
  static const blue = Color(0xFF1565C0);
  static const softPink = Color(0xFFFFF1F6);
  static const ink = Color(0xFF25232A);
  static const muted = Color(0xFF77727A);

  static ThemeData get light {
    final base = ThemeData(useMaterial3: true, brightness: Brightness.light);
    final textTheme = GoogleFonts.vazirmatnTextTheme(base.textTheme).apply(bodyColor: ink, displayColor: ink);
    return base.copyWith(
      textTheme: textTheme,
      scaffoldBackgroundColor: const Color(0xFFFFFCFD),
      colorScheme: ColorScheme.fromSeed(seedColor: pink, primary: pink, secondary: blue, surface: Colors.white),
      pageTransitionsTheme: const PageTransitionsTheme(builders: {
        TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
        TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
      }),
      appBarTheme: AppBarTheme(
        backgroundColor: const Color(0xFFFFF8FA), foregroundColor: ink, elevation: 0,
        centerTitle: true,
        titleTextStyle: GoogleFonts.vazirmatn(color: ink, fontSize: 19, fontWeight: FontWeight.w800),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: const Color(0xFFF7F7FB),
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
      ),
      cardTheme: CardTheme(
        elevation: 0, color: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: const BorderSide(color: Color(0xFFF1E9ED))),
      ),
      filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
        backgroundColor: pink, foregroundColor: Colors.white,
        textStyle: GoogleFonts.vazirmatn(fontWeight: FontWeight.w800),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      )),
      chipTheme: base.chipTheme.copyWith(
        labelStyle: GoogleFonts.vazirmatn(fontWeight: FontWeight.w600),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }
}
