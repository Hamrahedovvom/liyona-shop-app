import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';

class HtmlContent extends StatelessWidget {
  final String html;
  final double fontSize;
  const HtmlContent({super.key, required this.html, this.fontSize = 15});

  @override
  Widget build(BuildContext context) {
    if (html.trim().isEmpty) return const SizedBox.shrink();
    final normalized = html.replaceAll(RegExp(r'\r\n|\r|\n'), '<br>');
    return Html(
      data: normalized,
      style: {
        'body': Style(
          margin: Margins.zero,
          padding: HtmlPaddings.zero,
          direction: TextDirection.rtl,
          textAlign: TextAlign.right,
          fontSize: FontSize(fontSize),
          lineHeight: const LineHeight(1.9),
          color: const Color(0xFF3F3940),
        ),
        'p': Style(
          margin: Margins.only(bottom: 12),
          direction: TextDirection.rtl,
          textAlign: TextAlign.right,
        ),
        'li': Style(
          margin: Margins.only(bottom: 7),
          direction: TextDirection.rtl,
          textAlign: TextAlign.right,
        ),
        'h1': Style(fontWeight: FontWeight.w900, fontSize: FontSize(fontSize + 5)),
        'h2': Style(fontWeight: FontWeight.w900, fontSize: FontSize(fontSize + 4)),
        'h3': Style(fontWeight: FontWeight.w900, fontSize: FontSize(fontSize + 2)),
        'strong': Style(fontWeight: FontWeight.w900),
      },
    );
  }
}
