import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/product.dart';
import '../screens/product_detail_screen.dart';

class ExploreGrid extends StatelessWidget {
  final List<Product> products;
  final bool shrinkWrap;
  final ScrollPhysics? physics;
  final EdgeInsetsGeometry padding;
  const ExploreGrid({
    super.key,
    required this.products,
    this.shrinkWrap = true,
    this.physics,
    this.padding = const EdgeInsets.symmetric(horizontal: 2),
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: shrinkWrap,
      physics: physics ?? (shrinkWrap ? const NeverScrollableScrollPhysics() : null),
      padding: padding,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 1,
        crossAxisSpacing: 2,
        mainAxisSpacing: 2,
      ),
      itemCount: products.length,
      itemBuilder: (context, i) {
        final p = products[i];
        return InkWell(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ProductDetailScreen(product: p)),
          ),
          child: ColoredBox(
            color: const Color(0xFFF3F3F3),
            child: p.image.isEmpty
                ? const Center(child: Icon(Icons.image_outlined, color: Colors.black26))
                : CachedNetworkImage(
                    imageUrl: p.image,
                    fit: BoxFit.cover,
                    fadeInDuration: const Duration(milliseconds: 160),
                    memCacheWidth: 600,
                    placeholder: (_, __) => const ColoredBox(color: Color(0xFFF1F1F1)),
                    errorWidget: (_, __, ___) => const Center(
                      child: Icon(Icons.broken_image_outlined, color: Colors.black26),
                    ),
                  ),
          ),
        );
      },
    );
  }
}
