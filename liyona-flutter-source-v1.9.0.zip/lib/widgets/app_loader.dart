import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import '../core/theme.dart';

class LiyonaLoader extends StatelessWidget {
  final double size;
  const LiyonaLoader({super.key, this.size = 72});

  @override
  Widget build(BuildContext context) => Center(
        child: TweenAnimationBuilder<double>(
          tween: Tween(begin: .85, end: 1),
          duration: const Duration(milliseconds: 700),
          curve: Curves.easeInOut,
          builder: (_, v, child) => Transform.scale(scale: v, child: child),
          child: Container(
            width: size,
            height: size,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Colors.black.withOpacity(.06), blurRadius: 18)]),
            child: Image.asset('assets/images/app_icon_1024.png'),
          ),
        ),
      );
}

class ProductSkeleton extends StatelessWidget {
  const ProductSkeleton({super.key});
  @override
  Widget build(BuildContext context) => Shimmer.fromColors(
        baseColor: const Color(0xFFF2ECEF),
        highlightColor: Colors.white,
        child: Row(
          children: List.generate(
            2,
            (_) => Expanded(
              child: Container(
                height: 260,
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
              ),
            ),
          ),
        ),
      );
}

class LiyonaProgress extends StatelessWidget {
  final double value;
  const LiyonaProgress({super.key, required this.value});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(99),
        child: LinearProgressIndicator(
          minHeight: 8,
          value: value.clamp(0, 1),
          backgroundColor: const Color(0xFFFFE7F0),
          valueColor: const AlwaysStoppedAnimation(LiyonaTheme.pink),
        ),
      );
}
