# Liyona Shop v1.8.2
Build maintenance release: Android host is recreated for Flutter 3.24.5 and the generated template widget test is removed before analysis/build.
