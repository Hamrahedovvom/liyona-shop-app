import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../services/api.dart';
import '../widgets/app_loader.dart';
import 'category_products_screen.dart';

class CategoriesScreen extends StatefulWidget {
  final int parentId;
  final String title;
  const CategoriesScreen({super.key, this.parentId = 0, this.title = 'دسته‌بندی محصولات'});
  @override State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  late Future<List<dynamic>> future;
  @override void initState(){super.initState();future=api.categories(parent: widget.parentId);}

  Future<void> open(Map<String,dynamic> c) async {
    final children = await api.categories(parent: (c['id'] as num?)?.toInt() ?? 0);
    if (!mounted) return;
    if (children.isNotEmpty) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => CategoriesScreen(parentId: (c['id'] as num?)?.toInt() ?? 0, title: (c['name']??'').toString())));
    } else {
      Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryProductsScreen(name:(c['name']??'').toString(),slug:(c['slug']??'').toString())));
    }
  }

  @override Widget build(BuildContext context)=>SafeArea(child:FutureBuilder<List<dynamic>>(
    future: future,builder:(context,s){
      if(s.connectionState!=ConnectionState.done)return const LiyonaLoader();
      if(s.hasError)return const Center(child:Text('دریافت دسته‌بندی‌ها ناموفق بود'));
      final items=s.data??[];
      return CustomScrollView(slivers:[
        SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(18,22,18,10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(widget.title,style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.w900)),
          const SizedBox(height:6),const Text('دسته مورد نظرت رو انتخاب کن',style:TextStyle(color:Colors.black54))]))),
        SliverPadding(padding:const EdgeInsets.all(14),sliver:SliverGrid(gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:.95),delegate:SliverChildBuilderDelegate((context,i){
          final c=Map<String,dynamic>.from(items[i]);final image=(c['image']??'').toString();
          return InkWell(borderRadius:BorderRadius.circular(22),onTap:()=>open(c),child:Card(clipBehavior:Clip.antiAlias,child:Stack(fit:StackFit.expand,children:[
            image.isEmpty?Container(color:const Color(0xFFFFEEF4),child:const Icon(Icons.category_outlined,size:48,color:Colors.black26)):CachedNetworkImage(imageUrl:image,fit:BoxFit.cover,errorWidget:(_,__,___)=>Container(color:const Color(0xFFFFEEF4))),
            const DecoratedBox(decoration:BoxDecoration(gradient:LinearGradient(colors:[Colors.transparent,Color(0xB3000000)],begin:Alignment.topCenter,end:Alignment.bottomCenter))),
            Positioned(right:12,left:12,bottom:12,child:Row(children:[Expanded(child:Text((c['name']??'').toString(),style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w900,fontSize:17))),const Icon(Icons.chevron_left,color:Colors.white)]) )
          ])));
        },childCount:items.length)))
      ]);
    }));
}
