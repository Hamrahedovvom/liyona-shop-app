import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../services/api.dart';
import '../widgets/contact_sheet.dart';
import 'home_screen.dart';
import 'categories_screen.dart';
import 'cart_screen.dart';
import 'account_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  int cartCount = 0;

  @override
  void initState() {
    super.initState();
    _refreshCartCount();
  }

  Future<void> _refreshCartCount() async {
    try {
      final c = await api.cart();
      final items = List<dynamic>.from(c['items'] ?? []);
      if (mounted) setState(() => cartCount = items.fold<int>(0, (s, e) => s + ((e['quantity'] as num?)?.toInt() ?? 0)));
    } catch (_) {}
  }

  void select(int i) {
    setState(() => index = i);
    if (i == 2) _refreshCartCount();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeScreen(onSelectTab: select),
      const CategoriesScreen(),
      CartScreen(onCartChanged: _refreshCartCount),
      const AccountScreen(),
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: IndexedStack(index: index, children: pages),
        floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
        floatingActionButton: Padding(
          padding: const EdgeInsets.only(bottom: 72),
          child: FloatingActionButton.small(
            heroTag: 'contact-fab',
            onPressed: () => showContactSheet(context),
            backgroundColor: LiyonaTheme.ink,
            foregroundColor: Colors.white,
            child: const Icon(Icons.support_agent),
          ),
        ),
        bottomNavigationBar: SafeArea(
          top: false,
          child: Container(
            margin: const EdgeInsets.fromLTRB(14, 0, 14, 10),
            padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(28),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(.08), blurRadius: 24, offset: const Offset(0, 8))],
            ),
            child: Row(
              children: [
                _NavItem(index: 0, current: index, icon: Icons.home_rounded, label: 'خانه', onTap: select),
                _NavItem(index: 1, current: index, icon: Icons.grid_view_rounded, label: 'دسته‌بندی', onTap: select),
                _NavItem(index: 2, current: index, icon: Icons.shopping_bag_rounded, label: 'سبد خرید', badge: cartCount, onTap: select),
                _NavItem(index: 3, current: index, icon: Icons.person_rounded, label: 'حساب من', onTap: select),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final int index;
  final int current;
  final IconData icon;
  final String label;
  final int badge;
  final ValueChanged<int> onTap;
  const _NavItem({required this.index, required this.current, required this.icon, required this.label, required this.onTap, this.badge = 0});

  @override
  Widget build(BuildContext context) {
    final selected = index == current;
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => onTap(index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 4),
          decoration: BoxDecoration(color: selected ? const Color(0xFFFFE5EF) : Colors.transparent, borderRadius: BorderRadius.circular(20)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(clipBehavior: Clip.none, children: [
                AnimatedScale(scale: selected ? 1.08 : .96, duration: const Duration(milliseconds: 220), child: Icon(icon, color: selected ? LiyonaTheme.pink : const Color(0xFF5F5960), size: 25)),
                if (badge > 0)
                  Positioned(
                    top: -8, left: -12,
                    child: Container(
                      constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: const BoxDecoration(color: LiyonaTheme.pink, shape: BoxShape.circle),
                      alignment: Alignment.center,
                      child: Text('$badge', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900)),
                    ),
                  ),
              ]),
              const SizedBox(height: 3),
              Text(label, style: TextStyle(fontSize: 11, fontWeight: selected ? FontWeight.w900 : FontWeight.w600, color: selected ? LiyonaTheme.pink : const Color(0xFF5F5960))),
            ],
          ),
        ),
      ),
    );
  }
}
