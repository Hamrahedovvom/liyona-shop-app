import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../services/api.dart';
import '../models/product.dart';
import '../widgets/product_card.dart';
import '../widgets/app_loader.dart';
import '../core/theme.dart';
import 'category_products_screen.dart';

class HomeScreen extends StatefulWidget {
  final ValueChanged<int> onSelectTab;
  const HomeScreen({super.key, required this.onSelectTab});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ScrollController controller = ScrollController();
  final TextEditingController search = TextEditingController();
  late Future<List<dynamic>> cats;
  bool showTop = false;

  @override
  void initState() {
    super.initState();
    cats = api.categories(parent: 0);
    controller.addListener(() {
      final next = controller.offset > 500;
      if (next != showTop && mounted) setState(() => showTop = next);
    });
  }

  @override
  void dispose() {
    controller.dispose();
    search.dispose();
    super.dispose();
  }

  Future<void> refresh() async {
    api.invalidate('products');
    api.invalidate('categories');
    setState(() => cats = api.categories(parent: 0));
    await cats;
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Stack(
        children: [
          RefreshIndicator(
            onRefresh: refresh,
            child: CustomScrollView(
              controller: controller,
              slivers: [
                SliverAppBar(
                  pinned: true,
                  floating: true,
                  snap: true,
                  expandedHeight: 122,
                  toolbarHeight: 62,
                  backgroundColor: const Color(0xFFFFF8FA),
                  title: Image.asset('assets/images/liyona_logo.jpg', height: 42),
                  leading: IconButton(
                    onPressed: () => widget.onSelectTab(3),
                    icon: const Icon(Icons.person_outline),
                  ),
                  actions: [
                    IconButton(
                      onPressed: () => widget.onSelectTab(2),
                      icon: const Icon(Icons.shopping_bag_outlined),
                    ),
                  ],
                  flexibleSpace: FlexibleSpaceBar(
                    background: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 68, 16, 8),
                      child: TextField(
                        controller: search,
                        onSubmitted: (q) {
                          if (q.trim().isEmpty) return;
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => _AllProductsScreen(
                                title: 'نتایج جستجو',
                                future: api.products(search: q, perPage: 50),
                              ),
                            ),
                          );
                        },
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search),
                          hintText: 'جستجو بین محصولات لیونا...',
                        ),
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(28),
                        gradient: const LinearGradient(
                          colors: [Color(0xFFFFDDEB), Color(0xFFEAF1FF)],
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'لیونا؛ انتخاب تازه برای استایل تو',
                            style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: LiyonaTheme.pink),
                          ),
                          const SizedBox(height: 8),
                          const Text('جدیدترین محصولات، تخفیف‌ها و دسته‌بندی‌ها در یک نگاه'),
                          const SizedBox(height: 14),
                          FilledButton(
                            onPressed: () => widget.onSelectTab(1),
                            child: const Text('مشاهده دسته‌بندی‌ها'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: FutureBuilder<List<dynamic>>(
                    future: cats,
                    builder: (context, s) {
                      final items = s.data ?? [];
                      if (items.isEmpty) return const SizedBox.shrink();
                      return SizedBox(
                        height: 132,
                        child: ListView.separated(
                          reverse: true,
                          scrollDirection: Axis.horizontal,
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: items.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 10),
                          itemBuilder: (_, i) {
                            final c = Map<String, dynamic>.from(items[i]);
                            final image = (c['image'] ?? '').toString();
                            return InkWell(
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => CategoryProductsScreen(
                                    name: (c['name'] ?? '').toString(),
                                    slug: (c['slug'] ?? '').toString(),
                                  ),
                                ),
                              ),
                              child: SizedBox(
                                width: 88,
                                child: Column(
                                  children: [
                                    CircleAvatar(
                                      radius: 36,
                                      backgroundColor: const Color(0xFFFFE7EF),
                                      backgroundImage: image.isNotEmpty ? CachedNetworkImageProvider(image) : null,
                                      child: image.isEmpty ? const Icon(Icons.category_outlined) : null,
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      (c['name'] ?? '').toString(),
                                      maxLines: 2,
                                      textAlign: TextAlign.center,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
                ),
                SliverToBoxAdapter(
                  child: ProductSection(
                    title: 'جدیدترین محصولات',
                    future: api.products(perPage: 10),
                    onAll: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => _AllProductsScreen(
                          title: 'جدیدترین محصولات',
                          future: api.products(perPage: 50),
                        ),
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: SaleSection(
                    future: api.products(perPage: 12, onSale: true),
                    onAll: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => _AllProductsScreen(
                          title: 'پیشنهادهای ویژه',
                          future: api.products(perPage: 50, onSale: true),
                        ),
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: FutureBuilder<List<dynamic>>(
                    future: cats,
                    builder: (context, s) {
                      final items = s.data ?? [];
                      return Column(
                        children: items.map((raw) {
                          final c = Map<String, dynamic>.from(raw);
                          final name = (c['name'] ?? '').toString();
                          final slug = (c['slug'] ?? '').toString();
                          return ProductSection(
                            title: name,
                            future: api.products(category: slug, perPage: 8),
                            hideWhenEmpty: true,
                            onAll: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => CategoryProductsScreen(name: name, slug: slug),
                              ),
                            ),
                          );
                        }).toList(),
                      );
                    },
                  ),
                ),
                const SliverToBoxAdapter(child: SizedBox(height: 120)),
              ],
            ),
          ),
          if (showTop)
            Positioned(
              left: 16,
              bottom: 18,
              child: FloatingActionButton.small(
                heroTag: 'top-home',
                onPressed: () => controller.animateTo(
                  0,
                  duration: const Duration(milliseconds: 450),
                  curve: Curves.easeOutCubic,
                ),
                child: const Icon(Icons.keyboard_arrow_up),
              ),
            ),
        ],
      ),
    );
  }
}

class SectionHeader extends StatelessWidget {
  final String title;
  final VoidCallback onAll;
  const SectionHeader(this.title, this.onAll, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
        child: Row(
          children: [
            Expanded(child: Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900))),
            TextButton(onPressed: onAll, child: const Text('مشاهده همه')),
          ],
        ),
      );
}

class ProductSection extends StatelessWidget {
  final String title;
  final Future<List<Product>> future;
  final VoidCallback onAll;
  final bool hideWhenEmpty;
  const ProductSection({super.key, required this.title, required this.future, required this.onAll, this.hideWhenEmpty = false});

  @override
  Widget build(BuildContext context) => FutureBuilder<List<Product>>(
        future: future,
        builder: (context, s) {
          if (s.connectionState != ConnectionState.done) {
            return Column(children: [SectionHeader(title, onAll), const ProductSkeleton()]);
          }
          final items = s.data ?? [];
          if (items.isEmpty && hideWhenEmpty) return const SizedBox.shrink();
          return Column(
            children: [
              SectionHeader(title, onAll),
              if (items.isEmpty)
                const Padding(padding: EdgeInsets.all(26), child: Text('محصولی برای نمایش نیست'))
              else
                SizedBox(
                  height: 300,
                  child: ListView.separated(
                    reverse: true,
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (_, i) => SizedBox(width: 176, child: ProductCard(p: items[i])),
                  ),
                ),
            ],
          );
        },
      );
}

class SaleSection extends StatelessWidget {
  final Future<List<Product>> future;
  final VoidCallback onAll;
  const SaleSection({super.key, required this.future, required this.onAll});

  @override
  Widget build(BuildContext context) => FutureBuilder<List<Product>>(
        future: future,
        builder: (context, s) {
          final items = s.data ?? [];
          if (s.connectionState == ConnectionState.done && items.isEmpty) return const SizedBox.shrink();
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 14),
            padding: const EdgeInsets.only(bottom: 16),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [Color(0xFFE60064), Color(0xFFFF3F87)]),
            ),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
                  child: Row(
                    children: [
                      const Expanded(child: Text('شگفت‌انگیزهای لیونا', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900))),
                      TextButton(onPressed: onAll, child: const Text('مشاهده همه', style: TextStyle(color: Colors.white))),
                    ],
                  ),
                ),
                if (s.connectionState != ConnectionState.done)
                  const SizedBox(height: 240, child: LiyonaLoader())
                else
                  SizedBox(
                    height: 288,
                    child: ListView.separated(
                      reverse: true,
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      itemCount: items.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 10),
                      itemBuilder: (_, i) => SizedBox(width: 170, child: ProductCard(p: items[i])),
                    ),
                  ),
              ],
            ),
          );
        },
      );
}

class _AllProductsScreen extends StatelessWidget {
  final String title;
  final Future<List<Product>> future;
  const _AllProductsScreen({required this.title, required this.future});

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: Text(title)),
          body: FutureBuilder<List<Product>>(
            future: future,
            builder: (context, s) {
              if (s.connectionState != ConnectionState.done) return const LiyonaLoader();
              if (s.hasError) return const Center(child: Text('دریافت محصولات ناموفق بود'));
              final items = s.data ?? [];
              return GridView.builder(
                padding: const EdgeInsets.all(14),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: .62,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemCount: items.length,
                itemBuilder: (_, i) => ProductCard(p: items[i]),
              );
            },
          ),
        ),
      );
}
