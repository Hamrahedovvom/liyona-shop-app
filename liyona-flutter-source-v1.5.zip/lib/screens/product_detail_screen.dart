import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/product.dart';
import '../services/api.dart';
import '../core/theme.dart';
import '../utils/format.dart';
import '../widgets/app_loader.dart';
import 'cart_screen.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;
  const ProductDetailScreen({super.key, required this.product});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  late Future<Map<String, dynamic>> detail;
  int imageIndex = 0;
  int qty = 1;
  bool adding = false;
  final Map<String, String> selected = {};

  @override
  void initState() {
    super.initState();
    detail = api.product(widget.product.id);
  }

  List<String> images(Map<String, dynamic> d) {
    final out = <String>[];
    final main = (d['image'] ?? '').toString();
    if (main.isNotEmpty) out.add(main);
    for (final e in List<dynamic>.from(d['gallery'] ?? [])) {
      final u = e.toString();
      if (u.isNotEmpty && !out.contains(u)) out.add(u);
    }
    return out;
  }

  Map<String, dynamic>? matchedVariation(Map<String, dynamic> d) {
    final vars = List<dynamic>.from(d['variations'] ?? []);
    for (final raw in vars) {
      final v = Map<String, dynamic>.from(raw);
      final attrs = List<dynamic>.from(v['attributes'] ?? []);
      var ok = true;
      for (final rawAttr in attrs) {
        final a = Map<String, dynamic>.from(rawAttr);
        final name = (a['name'] ?? '').toString();
        final display = (a['display_option'] ?? a['option'] ?? '').toString();
        if (display.isNotEmpty && selected[name] != display) {
          ok = false;
          break;
        }
      }
      if (ok) return v;
    }
    return null;
  }

  Future<void> add(Map<String, dynamic> d) async {
    final attrs = List<dynamic>.from(d['attributes'] ?? [])
        .where((e) => Map<String, dynamic>.from(e)['variation'] == true)
        .toList();

    for (final raw in attrs) {
      final a = Map<String, dynamic>.from(raw);
      final name = (a['name'] ?? '').toString();
      if (!selected.containsKey(name)) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('لطفاً $name را انتخاب کنید')),
        );
        return;
      }
    }

    final isVariable = (d['type'] ?? '') == 'variable';
    final variation = isVariable ? matchedVariation(d) : null;
    if (isVariable && variation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('این ترکیب از گزینه‌ها موجود نیست')),
      );
      return;
    }
    if (variation != null && variation['in_stock'] == false) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('این گزینه در حال حاضر ناموجود است')),
      );
      return;
    }

    setState(() => adding = true);
    try {
      final id = variation == null ? widget.product.id : (variation['id'] as num).toInt();
      await api.addToCart(id, quantity: qty);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('محصول به سبد خرید اضافه شد')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('افزودن به سبد خرید ناموفق بود\n$e')),
      );
    } finally {
      if (mounted) setState(() => adding = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Image.asset('assets/images/liyona_logo.jpg', height: 42),
          actions: [
            IconButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CartScreen()),
              ),
              icon: const Icon(Icons.shopping_bag_outlined),
            ),
          ],
        ),
        body: FutureBuilder<Map<String, dynamic>>(
          future: detail,
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) return const LiyonaLoader();
            if (s.hasError) return const Center(child: Text('دریافت اطلاعات محصول ناموفق بود'));

            final d = s.data ?? {};
            final gallery = images(d);
            final attrs = List<dynamic>.from(d['attributes'] ?? [])
                .where((e) => Map<String, dynamic>.from(e)['variation'] == true)
                .toList();
            final variation = matchedVariation(d);
            final shownPrice = (variation?['price'] ?? d['price'] ?? '').toString();
            final desc = (d['description'] ?? '').toString();
            final short = (d['short_description'] ?? '').toString();
            final cats = List<dynamic>.from(d['categories'] ?? []);
            final tags = List<dynamic>.from(d['tags'] ?? []);

            return ListView(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
              children: [
                if (gallery.isNotEmpty) ...[
                  AspectRatio(
                    aspectRatio: 1,
                    child: Hero(
                      tag: 'product-${widget.product.id}',
                      child: Material(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(28),
                        clipBehavior: Clip.antiAlias,
                        child: InkWell(
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => GalleryScreen(images: gallery, initial: imageIndex),
                            ),
                          ),
                          child: CachedNetworkImage(
                            imageUrl: gallery[imageIndex],
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 80,
                    child: ListView.separated(
                      reverse: true,
                      scrollDirection: Axis.horizontal,
                      itemCount: gallery.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (_, i) => InkWell(
                        onTap: () => setState(() => imageIndex = i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: i == imageIndex ? LiyonaTheme.pink : Colors.transparent,
                              width: 2,
                            ),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(11),
                            child: CachedNetworkImage(
                              imageUrl: gallery[i],
                              width: 72,
                              height: 72,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 5),
                      child: Text(
                        '${imageIndex + 1} / ${gallery.length}',
                        style: const TextStyle(color: Colors.black54),
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 12),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        (d['name'] ?? widget.product.name).toString(),
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, height: 1.5),
                      ),
                    ),
                    IconButton(onPressed: () {}, icon: const Icon(Icons.favorite_border)),
                    IconButton(onPressed: () {}, icon: const Icon(Icons.share_outlined)),
                  ],
                ),
                if ((d['average_rating'] ?? '0').toString() != '0')
                  Row(
                    children: [
                      const Icon(Icons.star_rounded, color: Colors.amber, size: 20),
                      Text(' ${d['average_rating']}  '),
                      Text('${d['review_count'] ?? 0} نظر', style: const TextStyle(color: Colors.black54)),
                    ],
                  ),
                const SizedBox(height: 8),
                Text(
                  money(shownPrice),
                  style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: LiyonaTheme.pink),
                ),
                if (short.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text(short, style: const TextStyle(height: 1.9, color: Color(0xFF504B51))),
                ],
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF5F8),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.verified_outlined, color: LiyonaTheme.pink),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'ضمانت اصالت کالا  •  ارسال سریع  •  خرید امن',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),
                ),
                if (attrs.isNotEmpty) ...[
                  const SizedBox(height: 22),
                  const Text('انتخاب ویژگی‌ها', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 10),
                  ...attrs.map((raw) {
                    final a = Map<String, dynamic>.from(raw);
                    final name = (a['name'] ?? '').toString();
                    final options = List<dynamic>.from(a['options'] ?? [])
                        .map((e) => e.toString())
                        .where((e) => e.isNotEmpty)
                        .toList();
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(name, style: const TextStyle(fontWeight: FontWeight.w900)),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: options
                                .map(
                                  (o) => ChoiceChip(
                                    label: Text(o),
                                    selected: selected[name] == o,
                                    onSelected: (_) => setState(() => selected[name] = o),
                                  ),
                                )
                                .toList(),
                          ),
                        ],
                      ),
                    );
                  }),
                ],
                Row(
                  children: [
                    const Text('تعداد', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                    const Spacer(),
                    IconButton(
                      onPressed: qty > 1 ? () => setState(() => qty--) : null,
                      icon: const Icon(Icons.remove_circle_outline),
                    ),
                    Text('$qty', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                    IconButton(
                      onPressed: () => setState(() => qty++),
                      icon: const Icon(Icons.add_circle_outline),
                    ),
                  ],
                ),
                const Divider(height: 32),
                ExpansionSection(
                  title: 'توضیحات محصول',
                  child: Text(desc.isEmpty ? 'توضیحی ثبت نشده' : desc, style: const TextStyle(height: 2)),
                ),
                ExpansionSection(
                  title: 'مشخصات و اطلاعات',
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (cats.isNotEmpty)
                        MetaRow(
                          title: 'دسته‌بندی',
                          items: cats.map((e) => Map<String, dynamic>.from(e)['name'].toString()).toList(),
                        ),
                      if (tags.isNotEmpty)
                        MetaRow(
                          title: 'برچسب‌ها',
                          items: tags.map((e) => Map<String, dynamic>.from(e)['name'].toString()).toList(),
                        ),
                      if ((d['sku'] ?? '').toString().isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text('کد محصول: ${d['sku']}'),
                        ),
                    ],
                  ),
                ),
                ExpansionSection(
                  title: 'نظرات کاربران',
                  child: ReviewsList(productId: widget.product.id),
                ),
              ],
            );
          },
        ),
        bottomSheet: SafeArea(
          child: Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
            child: FutureBuilder<Map<String, dynamic>>(
              future: detail,
              builder: (context, s) => SizedBox(
                height: 54,
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: adding || !s.hasData ? null : () => add(s.data!),
                  icon: const Icon(Icons.shopping_bag_outlined),
                  label: Text(adding ? 'در حال افزودن...' : 'افزودن به سبد خرید'),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class GalleryScreen extends StatefulWidget {
  final List<String> images;
  final int initial;
  const GalleryScreen({super.key, required this.images, required this.initial});

  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  late PageController controller;
  late int index;

  @override
  void initState() {
    super.initState();
    index = widget.initial;
    controller = PageController(initialPage: index);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          title: Text('${index + 1} / ${widget.images.length}'),
        ),
        body: PageView.builder(
          controller: controller,
          onPageChanged: (v) => setState(() => index = v),
          itemCount: widget.images.length,
          itemBuilder: (_, i) => InteractiveViewer(
            minScale: 1,
            maxScale: 4,
            child: Center(
              child: CachedNetworkImage(imageUrl: widget.images[i], fit: BoxFit.contain),
            ),
          ),
        ),
      );
}

class ExpansionSection extends StatelessWidget {
  final String title;
  final Widget child;
  const ExpansionSection({super.key, required this.title, required this.child});

  @override
  Widget build(BuildContext context) => ExpansionTile(
        tilePadding: EdgeInsets.zero,
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
        children: [Padding(padding: const EdgeInsets.only(bottom: 14), child: child)],
      );
}

class MetaRow extends StatelessWidget {
  final String title;
  final List<String> items;
  const MetaRow({super.key, required this.title, required this.items});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('$title: ', style: const TextStyle(fontWeight: FontWeight.w800)),
            Expanded(
              child: Wrap(
                spacing: 6,
                runSpacing: 6,
                children: items.map((e) => Chip(label: Text(e))).toList(),
              ),
            ),
          ],
        ),
      );
}

class ReviewsList extends StatelessWidget {
  final int productId;
  const ReviewsList({super.key, required this.productId});

  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
        future: api.productReviews(productId),
        builder: (context, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Padding(padding: EdgeInsets.all(16), child: LiyonaLoader(size: 52));
          }
          final items = s.data ?? [];
          if (items.isEmpty) return const Text('هنوز نظری ثبت نشده');
          return Column(
            children: items.take(8).map((raw) {
              final r = Map<String, dynamic>.from(raw);
              return Card(
                child: ListTile(
                  title: Row(
                    children: [
                      Expanded(
                        child: Text(
                          (r['author'] ?? 'کاربر').toString(),
                          style: const TextStyle(fontWeight: FontWeight.w800),
                        ),
                      ),
                      const Icon(Icons.star, color: Colors.amber, size: 17),
                      Text((r['rating'] ?? '').toString()),
                    ],
                  ),
                  subtitle: Text((r['review'] ?? '').toString()),
                ),
              );
            }).toList(),
          );
        },
      );
}
